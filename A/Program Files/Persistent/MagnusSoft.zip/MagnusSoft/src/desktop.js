define([
{
   title: "WINDOWS 93"
  ,ico:"computer"
  //,exe:"computer"
  ,exe:"hello"
  ,help:"Type help for help"
}
,'<br>',
{
   title: "C:/"
  ,ico:"hd"
  ,url:"c/"
}
,'<br>',
{
   title: "Cat Explorer"
  ,ico:"nyanexplorer"
  //,ico:"/c/programs/apps/catExplorer/icon.gif"
  ,exe:"catex"
},{
   title: "Explorer"
  ,ico:"dora"
  ,exe:"dora --nav --list"
}/*,{
   title: "Terminal"
  ,ico:"terminal"
  ,exe:"terminal"
}*/
,'<br>',
{
   title: "Piskel"
  ,ico:"paint"
  ,url:"/c/programs/apps/piskel/index.html"
  ,help:"Piskel, a simple web-based tool for Spriting and Pixel art. Create pixel art, game sprites and animated GIFs.'<br>'by Julian Descottes and Vincent Renaudin'<br>'<a href='http://www.piskelapp.com/' target='_blank'>www.piskelapp.com</a>"
  ,width:"1200"
  ,height:"600"
},{
   title: "CodeMirror"
  ,ico:"codemirror"
  ,exe:"edit"
  ,width:"700"
  ,height:"500"
},/*{
   title: "Notes"
  ,exe:"note"
  ,ico:"pin"
},{
   exe:"brodkast"
  ,ico:"news"
  ,title: "brodkast"
},*/{
   //exe:"chat"
   error:"directX.dll missing dude,<br>cthulhu is using the chat<br>coming back soon"
  ,ico:"chat"
  ,title: "Clavardage"
},{
   //url:"/c/programs/apps/zkype/index.php"
   error: 'Warning, a satanic kitten orgy is happening on zkype right now... We are working hard restoring teh normality, stay tuned...'
  ,width:"700"
  ,height:"450"
  ,footer:"&nbsp;"
  ,ico:"zkype"
  ,title: "Zkype"
}/*,{
   exe:"tyl"
  ,width:"300"
  ,height:"450"
  ,ico:"/c/sys/ico32/tyl.png"
  ,title: "TYL"
}*/
,'<br>',
/*{
   url:"/c/programs/apps/bananamp/index.php"
  ,width:"700"
  ,height:"500"
  ,ico:"/c/programs/apps/bananamp/icon.png"
  ,title: "Bananamp"
},*/{
   exe:"pony"
  ,ico:"poney"
  ,title: "Poney Jockey"
},{
   exe:"bytebeat"
  ,ico:"/c/sys/ico32/bytebeat.png"
  ,title: "Byte Beat"
},{
   url:"/c/programs/apps/pukeData/index.html"
  ,width:"600"
  ,height:"400"
  ,help:"Random Drones Generator by Sébastien Piquemal"
  ,ico:"pd"
  ,title: "Puke Data"
},{
   url:"/c/programs/apps/speech/index.php"
  ,width:"200"
  ,height:"400"
  ,help:"chrome only..."
  ,ico:"voice"
  ,title: "Speech"
},{
   url:"/c/files/roms/dmg/music/lsdj3_1_9_demo.gb"
  ,ico:"lsdj"
  ,title: "LSDJ"
},{
   url:"/c/files/roms/dmg/music/nanoloop171d.gb"
  ,ico:"nanoloop"
  ,title: "Nanoloop"
},{
   url:"/c/files/roms/dmg/fail/Glitch_Grrrlz-Vol01.gbc"
  ,ico:"glitchgirlz"
  ,title: "Glitch Grrrlz"
}
,'<br>',
{
   url:"/c/programs/games/robby/index.html"
  ,width:"420"
  ,height:"400"
  ,help:"Robby : ascii based game by Morusque <3"
  ,ico:"robby"
  ,title: "Robby"
},{
   url:"/c/programs/demos/dangerous/index.html"
  ,width:"500"
  ,height:"440"
  ,footer:"&nbsp;"
  ,ico:"dangerous"
  ,title: "Take this"
},{
    url:"/c/files/roms/dmg/fail/Pokeglitch.gb"
  ,width:"320"
  ,height:"288"
  ,ico:"helix"
  ,title: "Pokégl̀ͤ͗̅͗̄̐̃ͬͮͣͩͮ̆̓́͛ͯͤͣͧ̔ͮ̈́ͯ̅۫ͫ̈́̊̃͛͐̎̂̓̃̇͛̍ͪͩ́͒͆̓̉̽̍̏͂ͮ̈́ͦ̀̀ͤ͗̅͗̄̐̃ͬͮͣͩͮ̆̓́͛ͯͤͣͧ̔ͮ̈́ͯ̅۫ͫ̈́̊̃͛͐̎̂̓̃̇͛̍ͪͩ́͒͆̓̉̽̍̏͂ͮ̈́ͦ̀ͤ͗̀ͤ͗̅͗̄̐̃ͬͮͣͩͮ̆̓́͛ͯͤͣͧ̔ͮ̈́ͯ̅۫ͫ̈́̊̃͛͐̎̂̓̃̇͛̍ͪͩ́͒͆̓̉̽̍̏͂ͮ̈́ͦ̀ͤ͗̀ͤ͗̅͗̄̐̃ͬͮͣͩͮ̆̓́͛ͯͤͣͧ̔ͮ̈́ͯ̅۫ͫ̈́̊̃͛͐̎̂̓̃̇͛̍ͪͩ́͒͆̓̉̽̍̏͂ͮ̈́ͦ̀ͤ͗̚̚̚̚̚̚̚̚̚ìͤ͗̅͗̄̐̃ͬͮͣͩͮ̆̓́͛ͯͤͣͧ̔ͮ̈́ͯ̅۫ͫ̈́̊̃͛͐̎̂̓̃̇͛̍ͪͩ́͒͆̓̉̽̍̏͂ͮ̈́ͦ̀ͤ͗̀ͤ͗̅͗̄̐̃ͬͮͣͩͮ̆̓́͛ͯͤͣͧ̔ͮ̈́ͯ̅۫ͫ̈́̊̃͛͐̎̂̓̃̇͛̍ͪͩ́͒͆̓̉̽̍̏͂ͮ̈́ͦ̀ͤ͗̀ͤ͗̅͗̄̐̃ͬͮͣͩͮ̆̓́͛ͯͤͣͧ̔ͮ̈́ͯ̅۫ͫ̈́̊̃͛͐̎̂̓̃̇͛̍ͪͩ́͒͆̓̉̽̍̏͂ͮ̈́ͦ̀ͤ͗̀ͤ͗̅͗̄̐̃ͬͮͣͩͮ̆̓́͛ͯͤͣͧ̔ͮ̈́ͯ̅۫ͫ̈́̊̃͛͐̎̂̓̃̇͛̍ͪͩ́͒͆̓̉̽̍̏͂ͮ̈́ͦ̀ͤ͗̀ͤ͗̅͗̄̐̃ͬͮͣͩͮ̆̓́͛ͯͤͣ̚̚̚̚̚̚̚̚̚̚̚̚tͧ̔ͮ̈́ͯ̅۫ͫ̈́̊̃͛͐̎̂̓̃̇͛̍ͪͩ́͒͆̓̉̽̍̏͂ͮ̈́ͦ̀ͤ͗̀ͤ͗̅͗̄̐̃ͬͮͣͩͮ̆̓́͛ͯͤͣͧ̔ͮ̈́ͯ̅۫ͫ̈́̊̃͛͐̎̂̓̃̇͛̍ͪͩ́͒͆̓̉̽̍̏͂ͮ̈́ͦ̀ͤ͗̀ͤ͗̅͗̄̐̃ͬͮͣͩͮ̆̓́͛ͯͤͣͧ̔ͮ̈́ͯ̅۫ͫ̈́̊̃͛͐̎̂̓̃̇͛̍ͪͩ́͒͆̓̉̽̍̏͂ͮ̈́ͦ̀ͤ͗̀ͤ͗̅͗̄̐̃ͬͮͣͩͮ̆̓́͛ͯͤͣͧ̔ͮ̈́ͯ̅۫ͫ̈́̊̃͛͐̎̂̓̃̇͛̍ͪͩ́͒͆̓̉̽̍̏͂ͮ̈́ͦ̀ͤ͗ͤ͗̚̚̚̚̚̚̚̚̚̚̚̚̚̚̚tch"
},{
   title: "What If?"
  ,ico:"matrix"
  ,url:"/c/programs/demos/matrix/index.php"
  ,width:"600"
  ,height:"400"
},{
   title: "Virtual PC"
  ,ico:"inception"
  ,url:"https://windows93.herokuapp.com/index.html"
  ,width:"600"
  ,height:"400"
  ,help:"INCEPTION"
},{
   title: "WIN93TOUR simulator"
  ,ico:"/c/sys/ico32/wintour.gif"
  ,width: 640
  ,height: 480
  ,url:"c/programs/games/euroDrunkSimulator/index.html"
},{
   title: "HAMPSTER"
  ,ico:"/c/programs/demos/hampsterDance/icon.gif"
  ,url:"/c/programs/demos/hampsterDance/index.html"
  ,bodyClass: "skin_light skin_inset"
  ,width:"600"
  ,height:"400"
}
,'<br>',
/*{
   title: "Tunnel"
  ,ico:"tunnel"
  ,url:"/c/programs/demos/tunnel/index.html"
  ,width:"500"
  ,height:"440"
},*/{
   title: "lenna.png"
  ,ico:"img"
  ,url:"/c/files/images/png/lenna.png"
  ,bodyClass:"noscroll"
  ,width:"512"
  ,height:"512"
},{
   title: "Star Wars.avi"
  ,ico:"yoda"
  ,url:"/c/programs/demos/starwars/index.html"
  ,width:"890"
  ,height:"344"
  ,help:"Star Wars Asciimation created by <a href=http://www.asciimation.co.nz/ target=_blank>www.asciimation.co.nz</a>"
},{
   title: "Corglitch"
  ,ico:"corgi"
  ,exe:"glitch"
},{
   title: "FramaPad"
  ,ico:"framapad"
  /*,url:"http://lite4.framapad.org/p/windows93"*/ // diz 1 was broke by uzerz a long time ago
  ,url:"https://lite4.framapad.org/p/windows93"
  ,width:"800"
  ,height:"600"
},
/*
{   title: "FramaTalk"
  ,ico:"video"
  ,url:"https://framatalk.org/windows93"
  ,width:"800"
  ,height:"600"
},
*/
{
   title: "Doctor Marburg"
  ,ico:"doctor"
  ,exe:"doctor"
},{
   title: "DEREG32 .EXE"
  ,ico:"sick"
  ,exe:"marburg"
},{
   title: "POTATO"
  ,ico:"/c/sys/ico32/potato.png"
  ,exe: 'potato'
},{
   title: "ANTHOLOGY"
  ,ico:"/c/sys/ico32/trophy.gif"
  ,exe: 'anthology'
}
,'<br>',
{
   title: "Virtual Girl"
  ,ico:"annaKournikova"
  ,exe:"lisa"
},{
   title: "Hydra.exe"
  ,ico:"hydra"
  ,exe:"hydra"
  ,arg:"['hi','hydra']"
},{
   title: "Acid Box 93"
  ,ico:"acidBox"
  ,url:"/c/programs/demos/acidBox93/index.html"
  ,width:"600"
  ,height:"400"
  ,help:"Demoscene tribute 4 Acid loverz...'<br>' Acid mix by Dj Invisible Pink'<br>'Cracktro Maded with CODEF <3"
},{
   title: "Arena 93"
  ,ico:"arena93"
  ,url:"/c/programs/games/Arena93/index.html"
  ,width:"600"
  ,height:"400"
},{
   title: "Game Of Life"
  ,ico:"gameOfLife"
  ,url:"/c/programs/demos/gameOfLife/index.html"
  ,width:"600"
  ,height:"600"
},{
   title: "Solitude"
  ,ico:"solitaire"
  ,exe:"solitude"
},{
   title: "Castle GAFA 3D"
  ,ico:"/c/programs/games/castleGafa/icon.gif"
  ,exe: "castlegafa"
  //,url:"/c/programs/games/castleGafa/index.html"
  //,url:"/c/programs/games/castleGafa2/index.php"
  //,width:"640"
  //,height:"400"
},{
   title: "Defrag"
  ,ico:"defrag"
  ,url:"/c/programs/games/defrag/index.php"
  ,width:"640"
  ,height:"495"
}
,'<br>',
{
   title: "Totally not a virus.Trust me...im a dolphin"
  ,ico:"dolphin"
  ,exe:"gravity"
},{
   title: "OLDEST GIF OF THE INTERWEBZ.gif"
  ,ico:"img"
  ,url:"/c/files/images/gif/wind.gif"
  ,width:"148"
  ,height:"175"
},{
   title: "MANIFESTO"
  ,ico:"question"
  ,exe:"manifesto"
},{
   title: "Credits"
  ,ico:"txt"
  ,url:"/c/credits.html"
  ,bodyClass: "skin_light skin_inset"
  ,width:"450"
  ,height:"300"
},
/*
{
   title: "Jankenpopp"
  ,ico:"/c/sys/ico32/network.png"
  ,url:"http://pierrepapierciseaux.net/jknppp/index.html"
  ,width:"600"
  ,height:"400"
},{
   title: "Zombectro"
  ,ico:"network"
  ,url:"http://www.zombect.ro/"
  ,width:"600"
  ,height:"400"
},
*/
{
   title: "WINDOWS93 HAZ A BAND"
  ,ico:"/c/sys/ico32/sound_on.png"
  ,exe: 'live'
},{
   title: "Contact us"
  ,ico:"mail"
  ,exe:"contact"
}
,'<br>',
{
   title: "TRASH"
  ,ico:"recycle_bin"
  ,url:"/c/trash/"
  ,width:"440"
  ,height:"330"
}
])
