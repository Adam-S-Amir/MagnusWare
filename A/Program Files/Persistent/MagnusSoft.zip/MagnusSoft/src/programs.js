function show_help(options) {
	const $help_window = $Window({
		title: options.title || "Help Topics",
		icon: "chm",
	})
	$help_window.addClass("help-window");

	let ignore_one_load = true;
	let back_length = 0;
	let forward_length = 0;

	const $main = $(E("div")).addClass("main");
	const $toolbar = $(E("div")).addClass("toolbar");
	const add_toolbar_button = (name, sprite_n, action_fn, enabled_fn) => {
		const $button = $("<button class='lightweight'>")
			.text(name)
			.appendTo($toolbar)
			.on("click", () => {
				action_fn();
			});
		$("<div class='icon'/>")
			.appendTo($button)
			.css({
				backgroundPosition: `${-sprite_n * 55}px 0px`,
			});
		const update_enabled = () => {
			$button[0].disabled = enabled_fn && !enabled_fn();
		};
		update_enabled();
		$help_window.on("click", "*", update_enabled);
		$help_window.on("update-buttons", update_enabled);
		return $button;
	};
	const measure_sidebar_width = () =>
		$contents.outerWidth() +
		parseFloat(getComputedStyle($contents[0]).getPropertyValue("margin-left")) +
		parseFloat(getComputedStyle($contents[0]).getPropertyValue("margin-right")) +
		$resizer.outerWidth();
	const $hide_button = add_toolbar_button("Hide", 0, () => {
		const toggling_width = measure_sidebar_width();
		$contents.hide();
		$resizer.hide();
		$hide_button.hide();
		$show_button.show();
		$help_window.width($help_window.width() - toggling_width);
		$help_window.css("left", $help_window.offset().left + toggling_width);
	});
	const $show_button = add_toolbar_button("Show", 5, () => {
		$contents.show();
		$resizer.show();
		$show_button.hide();
		$hide_button.show();
		const toggling_width = measure_sidebar_width();
		$help_window.width($help_window.width() + toggling_width);
		$help_window.css("left", $help_window.offset().left - toggling_width);
		// $help_window.applyBounds() would push the window to fit (before trimming it only if needed)
		// Trim the window to fit (especially for if maximized)
		if ($help_window.offset().left < 0) {
			$help_window.width($help_window.width() + $help_window.offset().left);
			$help_window.css("left", 0);
		}
	}).hide();
	add_toolbar_button("Back", 1, () => {
		$iframe[0].contentWindow.history.back();
		ignore_one_load = true;
		back_length -= 1;
		forward_length += 1;
	}, () => back_length > 0);
	add_toolbar_button("Forward", 2, () => {
		$iframe[0].contentWindow.history.forward();
		ignore_one_load = true;
		forward_length -= 1;
		back_length += 1;
	}, () => forward_length > 0);
	add_toolbar_button("Options", 3, () => { }, () => false); // TODO: hotkey and underline on O
	add_toolbar_button("Web Help", 4, () => {
		iframe.src = "help/online_support.htm";
	});

	const $iframe = $Iframe({ src: "help/default.html" }).addClass("inset-deep");
	const iframe = $iframe[0];
	iframe.$window = $help_window; // for focus handling integration
	const $resizer = $(E("div")).addClass("resizer");
	const $contents = $(E("ul")).addClass("contents inset-deep");

	// TODO: fix race conditions
	$iframe.on("load", () => {
		if (!ignore_one_load) {
			back_length += 1;
			forward_length = 0;
		}
		iframe.contentWindow.location.href
		ignore_one_load = false;
		$help_window.triggerHandler("update-buttons");
	});

	$main.append($contents, $resizer, $iframe);
	$help_window.$content.append($toolbar, $main);

	$help_window.css({ width: 800, height: 714 });

	$iframe.attr({ name: "help-frame" });
	$iframe.css({
		backgroundColor: "white",
		border: "",
		margin: "1px",
	});
	$contents.css({
		margin: "1px",
	});
	$help_window.center();

	$main.css({
		position: "relative", // for resizer
	});

	const resizer_width = 4;
	$resizer.css({
		cursor: "ew-resize",
		width: resizer_width,
		boxSizing: "border-box",
		background: "var(--ButtonFace)",
		borderLeft: "1px solid var(--ButtonShadow)",
		boxShadow: "inset 1px 0 0 var(--ButtonHilight)",
		top: 0,
		bottom: 0,
		zIndex: 1,
	});
	$resizer.on("pointerdown", (e) => {
		let pointermove, pointerup;
		const getPos = (e) =>
			Math.min($help_window.width() - 100, Math.max(20,
				e.clientX - $help_window.$content.offset().left
			));
		$G.on("pointermove", pointermove = (e) => {
			$resizer.css({
				position: "absolute",
				left: getPos(e)
			});
			$contents.css({
				marginRight: resizer_width,
			});
		});
		$G.on("pointerup", pointerup = (e) => {
			$G.off("pointermove", pointermove);
			$G.off("pointerup", pointerup);
			$resizer.css({
				position: "",
				left: ""
			});
			$contents.css({
				flexBasis: getPos(e) - resizer_width,
				marginRight: "",
			});
		});
	});

	const parse_object_params = $object => {
		// parse an $(<object>) to a plain object of key value pairs
		const object = {};
		for (const param of $object.children("param").get()) {
			object[param.name] = param.value;
		}
		return object;
	};

	let $last_expanded;

	const $Item = text => {
		const $item = $(E("div")).addClass("item").text(text);
		$item.on("mousedown", () => {
			$contents.find(".item").removeClass("selected");
			$item.addClass("selected");
		});
		$item.on("click", () => {
			const $li = $item.parent();
			if ($li.is(".folder")) {
				if ($last_expanded) {
					$last_expanded.not($li).removeClass("expanded");
				}
				$li.toggleClass("expanded");
				$last_expanded = $li;
			}
		});
		return $item;
	};

	const $default_item_li = $(E("li")).addClass("page");
	$default_item_li.append($Item("Welcome to Help").on("click", () => {
		$iframe.attr({ src: "help/default.html" });
	}));
	$contents.append($default_item_li);

	function renderItem(source_li, $folder_items_ul) {
		const object = parse_object_params($(source_li).children("object"));
		if ($(source_li).find("li").length > 0) {

			const $folder_li = $(E("li")).addClass("folder");
			$folder_li.append($Item(object.Name));
			$contents.append($folder_li);

			const $folder_items_ul = $(E("ul"));
			$folder_li.append($folder_items_ul);

			$(source_li).children("ul").children().get().forEach((li) => {
				renderItem(li, $folder_items_ul);
			});
		} else {
			const $item_li = $(E("li")).addClass("page");
			$item_li.append($Item(object.Name).on("click", () => {
				$iframe.attr({ src: `${options.root}/${object.Local}` });
			}));
			if ($folder_items_ul) {
				$folder_items_ul.append($item_li);
			} else {
				$contents.append($item_li);
			}
		}
	}

	$.get(options.contentsFile, hhc => {
		$($.parseHTML(hhc)).filter("ul").children().get().forEach((li) => {
			renderItem(li, null);
		});
	});

	// @TODO: keyboard accessability
	// $help_window.on("keydown", (e)=> {
	// 	switch(e.keyCode){
	// 		case 37:
	// 			show_error_message("MOVE IT");
	// 			break;
	// 	}
	// });
	var task = new Task($help_window);
	task.$help_window = $help_window;
	return task;
}

function Notepad(file_path) {
	// TODO: DRY the default file names and title code (use document.title of the page in the iframe, in $IframeWindow)
	var document_title = file_path ? file_name_from_path(file_path) : "Untitled";
	var win_title = document_title + " - Notepad";
	// TODO: focus existing window if file is currently open?

	var $win = new $IframeWindow({
		src: "programs/notepad/index.html" + (file_path ? ("?path=" + file_path) : ""),
		icon: "notepad",
		title: win_title
	});
	$win.onFocus(() => {
		const textarea = $win.iframe.contentWindow.document.querySelector("textarea");
		if (textarea) {
			textarea.focus();
		}
	});
	return new Task($win);
}
Notepad.acceptsFilePaths = true;

function Paint(file_path) {
	var $win = new $IframeWindow({
		src: "programs/jspaint/index.html",
		icon: "paint",
		// NOTE: in Windows 98, "untitled" is lowercase, but TODO: we should just make it consistent
		title: "untitled - Paint"
	});

	var contentWindow = $win.$iframe[0].contentWindow;

	var waitUntil = function (test, interval, callback) {
		if (test()) {
			callback();
		} else {
			setTimeout(waitUntil, interval, test, interval, callback);
		}
	};

	// it seems like I should be able to use onload here, but when it works (overrides the function),
	// it for some reason *breaks the scrollbar styling* in jspaint
	// I don't know what's going on there

	// contentWindow.addEventListener("load", function(){
	// $(contentWindow).on("load", function(){
	// $win.$iframe.load(function(){
	// $win.$iframe[0].addEventListener("load", function(){
	waitUntil(function () {
		return contentWindow.set_as_wallpaper_centered;
	}, 500, function () {
		// TODO: maybe save the wallpaper in localStorage
		// TODO: maybe use blob URL (if only to not take up so much space in the inspector)
		contentWindow.systemSetAsWallpaperCentered = function (canvas) {
			$desktop.css({
				backgroundImage: "url(" + canvas.toDataURL() + ")",
				backgroundRepeat: "no-repeat",
				backgroundPosition: "center",
				backgroundSize: "auto",
			});
		};
		contentWindow.systemSetAsWallpaperTiled = function (canvas) {
			$desktop.css({
				backgroundImage: "url(" + canvas.toDataURL() + ")",
				backgroundRepeat: "repeat",
				backgroundPosition: "0 0",
				backgroundSize: "auto",
			});
		};

		let $help_window;
		contentWindow.show_help = () => {
			if ($help_window) {
				$help_window.focus();
				return;
			}
			$help_window = show_help({
				title: "Paint Help",
				contentsFile: "programs/jspaint/help/mspaint.hhc",
				root: "programs/jspaint/help",
			}).$help_window;
			$help_window.on("close", () => {
				$help_window = null;
			});
		};

		if (file_path) {
			withFilesystem(function () {
				var fs = BrowserFS.BFSRequire("fs");
				fs.readFile(file_path, function (err, buffer) {
					if (err) {
						return console.error(err);
					}
					const byte_array = new Uint8Array(buffer);
					const blob = new Blob([byte_array]);
					const file_name = file_path.replace(/.*\//g, "");
					const file = new File([blob], file_name);
					contentWindow.open_from_File(file, () => { });
				});
			});
		}

		var old_update_title = contentWindow.update_title;
		contentWindow.update_title = () => {
			old_update_title();
			$win.title(contentWindow.document.title);
		};
	});

	return new Task($win);
}
Paint.acceptsFilePaths = true;

function U2() {
	var $win = new $IframeWindow({
		src: "programs/toob.html",
		icon: "Youtube",
		title: "Youtube",
		innerWidth: 700,
		innerHeight: 600
	});
	return new Task($win);
}

function google() {
	var $win = new $IframeWindow({
		src: "programs/google.html",
		icon: "chrome",
		title: "Google",
		innerWidth: 700,
		innerHeight: 600
	});
	return new Task($win);
}

function Network() {
	var $win = new $IframeWindow({
		src: "./index.html",
		icon: "Network",
		title: "Network Neighborhood",
		innerWidth: 700,
		innerHeight: 600
	});
	return new Task($win);
}

function nyan() {
	var $win = new $IframeWindow({
		src: "programs/cats/ixquick/index.html",
		icon: "nyan",
		title: "Nyan Browser",
		innerWidth: 1000,
		innerHeight: 500
	});
	return new Task($win);
}


function tiktok() {
	var $win = new $IframeWindow({
		src: "programs/tiktok.html",
		icon: "tiktok",
		title: "TikTok",
		innerWidth: 700,
		innerHeight: 600
	});
	return new Task($win);
}

function Solitare() {
	var $win = new $IframeWindow({
		src: "programs/solitare/index.html",
		icon: "solitare",
		title: "Solitare",
		innerWidth: 1000,
		innerHeight: 500
	});
	return new Task($win);
}

function Minesweeper() {
	var $win = new $IframeWindow({
		src: "programs/minesweeper/index.html",
		icon: "minesweeper",
		title: "Minesweeper",
		innerWidth: 280,
		innerHeight: 320
	});
	return new Task($win);
}
function Chat() {
	var $win = new $IframeWindow({
		src: "../chat/index.php",
		icon: "Chat",
		title: "English Pricks",
		innerWidth: 1000,
		innerHeight: 500
	});
	return new Task($win);
}
function Fourty() {
	var $win = new $IframeWindow({
		src: "./2048.html",
		icon: "Twenty",
		title: "2048",
		innerWidth: 700,
		innerHeight: 600
	});
	return new Task($win);
}
function Cookie() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Cookies/index.html",
		icon: "Cookie",
		title: "Cookie Clicker",
		innerWidth: 500,
		innerHeight: 500
	});
	return new Task($win);
}
function Dino() {
	var $win = new $IframeWindow({
		src: "./Dino.html",
		icon: "Dino",
		title: "Chrome Dino",
		innerWidth: 700,
		innerHeight: 600
	});

	return new Task($win);
}
function Brain() {
	var $win = new $IframeWindow({
		src: "./Brain.html",
		icon: "Brain",
		title: "Brain",
		innerWidth: 700,
		innerHeight: 600
	});

	return new Task($win);
}
function Classics() {
	var $win = new $IframeWindow({
		src: "./Arcade.html",
		icon: "Classics",
		title: "Classic Arcade Games",
		innerWidth: 700,
		innerHeight: 600
	});

	return new Task($win);
}
function Mario() {
	var $win = new $IframeWindow({
		src: "./Mario.html",
		icon: "Mario",
		title: "Mario Games",
		innerWidth: 700,
		innerHeight: 600
	});

	return new Task($win);
}
function Minecraft() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Minecraft/index.html",
		icon: "Minecraft",
		title: "Minecraft",
		innerWidth: 1000,
		innerHeight: 500
	});

	return new Task($win);
}
function NoGame() {
	var $win = new $IframeWindow({
		src: "../../../../Games/NoGame/index.html",
		icon: "NoGame",
		title: "There is No Game",
		innerWidth: 500,
		innerHeight: 500
	});

	return new Task($win);
}
function Power() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Power_Player_Super_Joy_III/index.html",
		icon: "Power",
		title: "Power Player Super Joy III",
		innerWidth: 500,
		innerHeight: 500
	});

	return new Task($win);
}
function Rioluvania() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Rioluvania/index.html",
		icon: "Rioluvania",
		title: "Rioluvania",
		innerWidth: 500,
		innerHeight: 500
	});

	return new Task($win);
}
function TBOI() {
	var $win = new $IframeWindow({
		src: "../../../../Games/TBOI/index.html",
		icon: "TBOI",
		title: "The Binding of Isaac",
		innerWidth: 500,
		innerHeight: 500
	});

	return new Task($win);
}
function Rocket() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Rocket Custa/index.html",
		icon: "Rocket",
		title: "Rocket Custa",
		innerWidth: 500,
		innerHeight: 500
	});

	return new Task($win);
}
function Spelunky() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Spelunky/index.html",
		icon: "Spelunky",
		title: "Spelunky",
		innerWidth: 500,
		innerHeight: 500
	});

	return new Task($win);
}
function Button() {
	var $win = new $IframeWindow({
		src: "../../../../Toys/Button/index.html",
		icon: "Button",
		title: "Button",
		innerWidth: 300,
		innerHeight: 300
	});

	return new Task($win);
}
function Clock() {
	var $win = new $IframeWindow({
		src: "../../../../Toys/Clock/index.html",
		icon: "Clock",
		title: "Clock",
		innerWidth: 500,
		innerHeight: 500
	});

	return new Task($win);
}
function DVD() {
	var $win = new $IframeWindow({
		src: "../../../../Toys/DVD/index.html",
		icon: "DVD",
		title: "DVD Screensaver",
		innerWidth: 500,
		innerHeight: 500
	});

	return new Task($win);
}
function Matrix() {
	var $win = new $IframeWindow({
		src: "../../../../Toys/Matrix/index.html",
		icon: "Matrix",
		title: "Matrix Screensaver",
		innerWidth: 500,
		innerHeight: 500
	});

	return new Task($win);
}
function Fluid() {
	var $win = new $IframeWindow({
		src: "../../../../Toys/Fluid/index.html",
		icon: "Fluid",
		title: "Fluid Simulator",
		innerWidth: 500,
		innerHeight: 500
	});

	return new Task($win);
}
function Star() {
	var $win = new $IframeWindow({
		src: "../../../../Toys/StrWrz/index.html",
		icon: "Starwars",
		title: "Star Wars Episode IV",
		innerWidth: 830,
		innerHeight: 500
	});

	return new Task($win);
}
function Soda() {
	var $win = new $IframeWindow({
		src: "../../../../Toys/Soda/index.htm",
		icon: "Soda",
		title: "Vending Machine",
		innerWidth: 500,
		innerHeight: 500
	});

	return new Task($win);
}
function Ice() {
	var $win = new $IframeWindow({
		src: "./Dodo.html",
		icon: "Ice",
		title: "Ice Dodo",
		innerWidth: 700,
		innerHeight: 600
	});

	return new Task($win);
}
function Atlantis() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/Atlantis/index.html",
		icon: "Atlantis",
		title: "Gameboy Emulator",
		innerWidth: 500,
		innerHeight: 500
	});

	return new Task($win);
}
function Surf() {
	var $win = new $IframeWindow({
		src: "./Surf.html",
		icon: "Surf",
		title: "Microsoft Surf",
		innerWidth: 700,
		innerHeight: 600
	});

	return new Task($win);
}

function Hex() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/Race/index.html",
		icon: "Hex",
		title: "Hex GL",
		innerWidth: 500,
		innerHeight: 500
	});

	return new Task($win);
}

function Credit() {
	var $win = new $IframeWindow({
		src: "programs/notes/index.html",
		icon: "File",
		title: "Credits.txt",
		innerWidth: 500,
		innerHeight: 500
	});

	return new Task($win);
}

function Doom2() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Doom2/Doom2.exe.html",
		icon: "Doom_2",
		title: "Doom 2",
		innerWidth: 665,
		innerHeight: 436
	});

	return new Task($win);
}

function Master() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Master/Master.exe.html",
		icon: "Master",
		title: "The Master Levels for Doom 2",
		innerWidth: 665,
		innerHeight: 436
	});

	return new Task($win);
}

function UD2() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/UD2/UD2.exe.html",
		icon: "UD2",
		title: "The Ultimate Doom 2",
		innerWidth: 665,
		innerHeight: 436
	});

	return new Task($win);
}

function MSCMD() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/CMD.html",
		icon: "DOS",
		title: "MS-CMD",
		innerWidth: 665,
		innerHeight: 436
	});

	return new Task($win);
}

function StarDoom() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/StarWars/StarWars.exe.html",
		icon: "SDoom",
		title: "Star Wars Doom",
		innerWidth: 665,
		innerHeight: 436
	});

	return new Task($win);
}

function BatDoom() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Batman/Batman.exe.html",
		icon: "Batman",
		title: "Batman Doom",
		innerWidth: 665,
		innerHeight: 436
	});

	return new Task($win);
}

function BDoom2() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Brutal/Brutal.exe.html",
		icon: "BDoom",
		title: "Brutal Doom 2",
		innerWidth: 665,
		innerHeight: 436
	});

	return new Task($win);
}

function Nine() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/95/95.exe.html",
		icon: "95",
		title: "Windows 95",
		innerWidth: 665,
		innerHeight: 436
	});

	return new Task($win);
}


function div11() {
	var x = document.getElementById("myDIV11");
	if (x.style.display === "none") {
		x.style.display = "block";
	} else {
		x.style.display = "none";
	}
}

function div12() {
	var x = document.getElementById("myDIV12");
	if (x.style.display === "none") {
		x.style.display = "block";
	} else {
		x.style.display = "none";
	}
}

function Duke() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Duke/Duke.exe.html",
		icon: "Duke",
		title: "Duke 3D",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}

function GTA() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/GTA/GTA.exe.html",
		icon: "GTA",
		title: "Grand Theft Auto",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}

function DTrail() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Trail/Oregon.exe.html",
		icon: "Oregon",
		title: "Deluxe Oregon Trail",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}

function Trail() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Trail2/Oregon.exe.html",
		icon: "Trail",
		title: "Oregon Trail",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}

function Castle() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/CW/CW.exe.html",
		icon: "Castle",
		title: "Castle Wolfenstien",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}

function Doom() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Doom/Doom.exe.html",
		icon: "Doom",
		title: "Ultimate Doom",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}

function Heretic() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Heretic/Heretic.exe.html",
		icon: "Heretic",
		title: "Heretic",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}

function Heretic2() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Heretic2/Heretic2.exe.html",
		icon: "Heretic2",
		title: "Heretic 2",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}
function Hexen() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Hexen/Hexen.exe.html",
		icon: "Hexen",
		title: "Hexen",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}

function Plutonia() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Plutonia/Plutonia.exe.html",
		icon: "Plutonia",
		title: "Plutonia",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}

function Plutonia2() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Plutonia2/PL2.exe.html",
		icon: "Plutonia2",
		title: "Plutonia 2",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}

function TNT() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/TNT/TNT.exe.html",
		icon: "FDoom",
		title: "TNT",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}

function Sixty() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Doom64/64.exe.html",
		icon: "64",
		title: "Doom64",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}

function Zero() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Zero/Zero.exe.html",
		icon: "Zero",
		title: "Doom Zero",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}

function Quake() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Quake/Quake.exe.html",
		icon: "Quake",
		title: "Quake",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}

function Quake2() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Quake2/index.html",
		icon: "Quake2",
		title: "Quake 2",
		innerWidth: 500,
		innerHeight: 500
	});
	return new Task($win);
}

function Spear() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Spear/Spear.exe.html",
		icon: "Spear",
		title: "Spear of Destiny",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}

function Strife() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Strife/Strife.exe.html",
		icon: "Strife",
		title: "Strife",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}

function FreeDm() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/FreeDM/FreeDM.exe.html",
		icon: "FreeDoom",
		title: "FreeDM",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}

function Free1() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/free1/FreeDoom.exe.html",
		icon: "FreeDoom",
		title: "FreeDoom: Phase 1",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}

function Free2() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/free2/FreeDoom2.exe.html",
		icon: "FreeDoom",
		title: "FreeDoom: Phase 2",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}
function FDoom() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Doom/FDoom.exe.html",
		icon: "FreeDoom",
		title: "The Ultimate FreeDoom",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}
function FDoom2() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Doom2/FDoom2.exe.html",
		icon: "FreeDoom",
		title: "FreeDoom Phase 2: Hell on Earth",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}
function FDoom64() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Doom64/F64.exe.html",
		icon: "FreeDoom",
		title: "FreeDoom 64",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}
function FTNT() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/TNT/FTNT.exe.html",
		icon: "FreeDoom",
		title: "FreeDoom: TNT Evilution",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}
function FPL() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Plutonia/FPlutonia.exe.html",
		icon: "FreeDoom",
		title: "FreeDoom: The Plutonia Experiment",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}
function FPL2() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Plutonia2/FPl2.exe.html",
		icon: "FreeDoom",
		title: "FreeDoom: The Plutonia Experiment Phase 2",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}
function FChex() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Chex1/FChex.exe.html",
		icon: "FreeDoom",
		title: "FreeDoom: Chex Quest Phase 1",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}
function FChex2() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Chex2/FChex.exe.html",
		icon: "FreeDoom",
		title: "FreeDoom: Chex Quest Phase 2",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}
function FChex3() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Chex3/FChex.exe.html",
		icon: "FreeDoom",
		title: "FreeDoom: Chex Quest Phase 3",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}

function Wolf3D() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Wolf3D/Wolf.exe.html",
		icon: "Wolf_3d",
		title: "Wolf 3D",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}
function BTSX() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/BTSX/BTSX.exe.html",
		icon: "BTSX",
		title: "Back to Saturn X",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}
function BTSX2() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/BTSX2/BTSX2.exe.html",
		icon: "BTSX",
		title: "Back to Saturn X 2",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}
function Chex1() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Chex1/Chex.exe.html",
		icon: "Chex",
		title: "Chex Quest 1",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}
function Chex2() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Chex2/Chex.exe.html",
		icon: "Chex2",
		title: "Chex Quest 2",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}
function Chex3() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Chex3/Chex.exe.html",
		icon: "Chex3",
		title: "Chex Quest 3",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}
function Doom2D() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Doom2D/Doom2D.exe.html",
		icon: "2D",
		title: "Doom 2D",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}
function Dario1() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Mario/Mario.exe.html",
		icon: "Dario",
		title: "Mario Doom",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}
function Dario2() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Mario2/Mario2.exe.html",
		icon: "Dario",
		title: "Mario Doom 2",
		innerWidth: 665,
		innerHeight: 436
	});
	return new Task($win);
}
function Regular() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Dino/Regular/index.html",
		icon: "Dino",
		title: "Chrome Dino Game",
		innerWidth: 1000,
		innerHeight: 500
	});

	return new Task($win);
}
function BDay() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Dino/BDay/index.html",
		icon: "Dino",
		title: "Birthday Edition",
		innerWidth: 1000,
		innerHeight: 500
	});

	return new Task($win);
}
function D3D() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Dino/3D/3d/index.html",
		icon: "Dino",
		title: "3D Dino",
		innerWidth: 1000,
		innerHeight: 500
	});

	return new Task($win);
}
function Godzilla() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Dino/Godzilla.html",
		icon: "Dino",
		title: "Godzilla",
		innerWidth: 1000,
		innerHeight: 500
	});

	return new Task($win);
}
function Modz() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Dino/Mod/index.html",
		icon: "Dino",
		title: "Modded Chrome Dino Game",
		innerWidth: 1000,
		innerHeight: 500
	});

	return new Task($win);
}
function Sonic1() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Dino/Sonic/index.html",
		icon: "Dino",
		title: "Sonic v1.0",
		innerWidth: 1000,
		innerHeight: 500
	});

	return new Task($win);
}
function Sonic2() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Dino/BSonic/index.html",
		icon: "Dino",
		title: "Sonic v1.2",
		innerWidth: 1000,
		innerHeight: 500
	});

	return new Task($win);
}
function Batz() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Dino/Batman/Bats/Batman/index.html",
		icon: "Dino",
		title: "Batman",
		innerWidth: 1000,
		innerHeight: 500
	});

	return new Task($win);
}
function Halloween() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Dino/Halloween.html",
		icon: "Dino",
		title: "Halloween",
		innerWidth: 1000,
		innerHeight: 500
	});

	return new Task($win);
}
function Joker() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Dino/Joker/Jokes/Joker/index.html",
		icon: "Dino",
		title: "Joker",
		innerWidth: 1000,
		innerHeight: 500
	});

	return new Task($win);
}
function Mines1() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Dino/Minecraft.html",
		icon: "Dino",
		title: "Minecraft v1.0",
		innerWidth: 1000,
		innerHeight: 500
	});

	return new Task($win);
}
function Mines2() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Dino/Minecraft/index.html",
		icon: "Dino",
		title: "Minecraft v1.2",
		innerWidth: 1000,
		innerHeight: 500
	});

	return new Task($win);
}
function Naruto() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Dino/Naruto.html",
		icon: "Dino",
		title: "Naruto",
		innerWidth: 1000,
		innerHeight: 500
	});

	return new Task($win);
}
function Anime() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Dino/Anime/index.html",
		icon: "Dino",
		title: "Anime",
		innerWidth: 1000,
		innerHeight: 500
	});

	return new Task($win);
}

function DNyan() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Dino/Nyan.html",
		icon: "Dino",
		title: "Nyan",
		innerWidth: 1000,
		innerHeight: 500
	});

	return new Task($win);
}
function Santa() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Dino/Santa.html",
		icon: "Dino",
		title: "Santa Claus",
		innerWidth: 1000,
		innerHeight: 500
	});

	return new Task($win);
}
function DMario1() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Dino/Super_Mario/Mars/Mario/index.html",
		icon: "Dino",
		title: "Super Mario v1.",
		innerWidth: 1000,
		innerHeight: 500
	});

	return new Task($win);
}
function DMario2() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Dino/Mario/index.html",
		icon: "Dino",
		title: "Super Mario v1.2",
		innerWidth: 1000,
		innerHeight: 500
	});

	return new Task($win);
}
function DMario3() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Dino/Maro/index.html",
		icon: "Dino",
		title: "Super Mario v1.3",
		innerWidth: 1000,
		innerHeight: 500
	});

	return new Task($win);
}
function DMario4() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Dino/Marilol/index.html",
		icon: "Dino",
		title: "Super Mario v1.4",
		innerWidth: 1000,
		innerHeight: 500
	});

	return new Task($win);
}
function MegaMan() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Dino/MegaMan/index.html",
		icon: "Dino",
		title: "Mega-Man",
		innerWidth: 1000,
		innerHeight: 500
	});

	return new Task($win);
}
function Vivaldi() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Dino/Vivaldi/index.html",
		icon: "Dino",
		title: "Vivaldi",
		innerWidth: 1000,
		innerHeight: 500
	});

	return new Task($win);
}
function Covid() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Dino/Covid/index.html",
		icon: "Dino",
		title: "Covid",
		innerWidth: 1000,
		innerHeight: 500
	});

	return new Task($win);
}
function Fish() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Dino/Fish/index.html",
		icon: "Dino",
		title: "Fish",
		innerWidth: 1000,
		innerHeight: 500
	});

	return new Task($win);
}
function Guy() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Dino/Guy/index.html",
		icon: "Dino",
		title: "Kumamon Runner",
		innerWidth: 1000,
		innerHeight: 500
	});

	return new Task($win);
}
function Zombie() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Dino/Zombie/index.html",
		icon: "Dino",
		title: "Zombie Runner",
		innerWidth: 1000,
		innerHeight: 500
	});

	return new Task($win);
}
function Mario1() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Mario/Mario/index.html",
		icon: "Mario",
		title: "Modded Super Mario Bros.",
		innerWidth: 1000,
		innerHeight: 500
	});

	return new Task($win);
}
function Mario2() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Mario/Mario/super.html",
		icon: "Mario",
		title: "Super Mario Bros.",
		innerWidth: 1000,
		innerHeight: 500
	});

	return new Task($win);
}
function iMario() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Mario/infinite/index.html",
		icon: "Mario",
		title: "Infinite Mario",
		innerWidth: 660,
		innerHeight: 500
	});

	return new Task($win);
}
function Cat() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Mario/Catmario/chrome/index.html",
		icon: "Mario",
		title: "Cat Mario",
		innerWidth: 500,
		innerHeight: 500
	});

	return new Task($win);
}
function Mari0() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Mario/Mari0/Mari0.html",
		icon: "Mario",
		title: "Mari0",
		innerWidth: 500,
		innerHeight: 500
	});

	return new Task($win);
}
function Surf1() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/SURF/S.U.R.F%201.0/index.html",
		icon: "Surf",
		title: "Microsoft Surf 1.0",
		innerWidth: 660,
		innerHeight: 500
	});

	return new Task($win);
}
function Surf2() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/SURF/S.U.R.F%202.0/index.html",
		icon: "Surf",
		title: "Microsoft Surf 2.0",
		innerWidth: 660,
		innerHeight: 500
	});

	return new Task($win);
}
function Surf3() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/SURF/S.U.R.F%203.0/index.html",
		icon: "Surf",
		title: "Microsoft Surf 3.0",
		innerWidth: 660,
		innerHeight: 500
	});

	return new Task($win);
}
function D2TWID() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Doom4/D2TWID.exe.html",
		icon: "4",
		title: "D2TWID",
		innerWidth: 665,
		innerHeight: 436
	});

	return new Task($win);
}
function D4VW() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Doom4/D4VW.exe.html",
		icon: "4",
		title: "D4VW",
		innerWidth: 665,
		innerHeight: 436
	});

	return new Task($win);
}
function D64D2() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Doom4/D64D2.exe.html",
		icon: "4",
		title: "D64D2",
		innerWidth: 665,
		innerHeight: 436
	});

	return new Task($win);
}
function DCV() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Doom4/DCV.exe.html",
		icon: "4",
		title: "DCV",
		innerWidth: 665,
		innerHeight: 436
	});

	return new Task($win);
}
function INTERCEP() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Doom4/INTERCEP.exe.html",
		icon: "4",
		title: "INTERCEP",
		innerWidth: 665,
		innerHeight: 436
	});

	return new Task($win);
}
function KSSHT() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Doom4/KSSHT.exe.html",
		icon: "4",
		title: "KSSHT",
		innerWidth: 665,
		innerHeight: 436
	});

	return new Task($win);
}
function NEXCREDO() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Doom4/NEXCREDO.exe.html",
		icon: "4",
		title: "NEXCREDO",
		innerWidth: 665,
		innerHeight: 436
	});

	return new Task($win);
}
function REVERIE() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Doom4/REVERIE.exe.html",
		icon: "4",
		title: "REVERIE",
		innerWidth: 665,
		innerHeight: 436
	});

	return new Task($win);
}
function SCYTHE() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/MS-DOS/Doom4/SCYTHE.exe.html",
		icon: "4",
		title: "SCYTHE",
		innerWidth: 665,
		innerHeight: 436
	});

	return new Task($win);
}
function Ice() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/Ice/Ice%20old/index.html",
		icon: "Ice",
		title: "Ice Dodo 1.0",
		innerWidth: 500,
		innerHeight: 500
	});

	return new Task($win);
}
function Ice2() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/Ice/Ice/index.html",
		icon: "Ice",
		title: "Ice Dodo 1.2",
		innerWidth: 500,
		innerHeight: 500
	});

	return new Task($win);
}
function Contranoid() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Brain_Games/Contranoid/www/index.html",
		icon: "Contranoid",
		title: "Contranoid",
		innerWidth: 500,
		innerHeight: 500
	});

	return new Task($win);
}
function Hi() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Brain_Games/Oh_hi/www/index.html",
		icon: "H1",
		title: "OH H1",
		innerWidth: 500,
		innerHeight: 500
	});

	return new Task($win);
}
function No() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Brain_Games/Oh_No/www/index.html",
		icon: "N0",
		title: "OH N0",
		innerWidth: 500,
		innerHeight: 500
	});

	return new Task($win);
}
function Quento() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Brain_Games/Quento/index.html",
		icon: "Quento",
		title: "Quento",
		innerWidth: 500,
		innerHeight: 621
	});

	return new Task($win);
}
function Hextris() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Brain_Games/Hextris/index.html",
		icon: "Hextris",
		title: "Hextris",
		innerWidth: 500,
		innerHeight: 500
	});

	return new Task($win);
}
function Pac1() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Classics/Pac_Man/Pac_Man_SOUND/index.html",
		icon: "Pacman",
		title: "Pac-Man 1.0",
		innerWidth: 500,
		innerHeight: 500
	});

	return new Task($win);
}
function Pac2() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Classics/Pac_Man/Pacman/index.htm",
		icon: "Pacman",
		title: "Pac-Man 1.2",
		innerWidth: 500,
		innerHeight: 500
	});

	return new Task($win);
}
function Google1() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Classics/Pac_Man/google-pacman-master/original/index.html",
		icon: "Pacman",
		title: "Google Pac-Man 1.2",
		innerWidth: 1000,
		innerHeight: 500
	});

	return new Task($win);
}
function Google2() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Classics/Pac_Man/google-pacman-master/index.html",
		icon: "Pacman",
		title: "Google Pac-Man 1.0",
		innerWidth: 1000,
		innerHeight: 500
	});

	return new Task($win);
}
function Atari() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Classics/breakout.html",
		icon: "Atari",
		title: "Atari Breakout",
		innerWidth: 500,
		innerHeight: 500
	});

	return new Task($win);
}
function Snake() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Classics/snake.html",
		icon: "Snake",
		title: "Snake",
		innerWidth: 500,
		innerHeight: 500
	});

	return new Task($win);
}
function Pong() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Classics/Pong/game.html",
		icon: "Pong",
		title: "Pong",
		innerWidth: 660,
		innerHeight: 505
	});

	return new Task($win);
}
function Tetris() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Classics/tetris.html",
		icon: "Tetris",
		title: "Tetris",
		innerWidth: 500,
		innerHeight: 621
	});

	return new Task($win);
}
function Space() {
	var $win = new $IframeWindow({
		src: "../../../../Games/Classics/Spice_Inventors/index.html",
		icon: "Space",
		title: "Space Invaders",
		innerWidth: 850,
		innerHeight: 560
	});

	return new Task($win);
}
function Twenty() {
	var $win = new $IframeWindow({
		src: "../../../../Games/2048/2048/index.html",
		icon: "Twenty",
		title: "2048",
		innerWidth: 500,
		innerHeight: 500
	});
	return new Task($win);
}
function One() {
	var $win = new $IframeWindow({
		src: "../../../../Games/2048/Flappy-2048/index.html",
		icon: "Twenty",
		title: "Flappy 2048 1.0",
		innerWidth: 500,
		innerHeight: 500
	});
	return new Task($win);
}
function Two() {
	var $win = new $IframeWindow({
		src: "../../../../Games/2048/2.0/index.html",
		icon: "Twenty",
		title: "Flappy 2048 2.0",
		innerWidth: 500,
		innerHeight: 500
	});
	return new Task($win);
}
function Three() {
	var $win = new $IframeWindow({
		src: "../../../../Games/2048/2048-3D/index.html",
		icon: "Twenty",
		title: "2048 3D",
		innerWidth: 1000,
		innerHeight: 500
	});
	return new Task($win);
}
function Four() {
	var $win = new $IframeWindow({
		src: "../../../../Games/2048/4/index.html",
		icon: "Twenty",
		title: "4",
		innerWidth: 500,
		innerHeight: 500
	});
	return new Task($win);
}
function AI() {
	var $win = new $IframeWindow({
		src: "../../../../Games/2048/2048-AI/index.html",
		icon: "Twenty",
		title: "2048 AI",
		innerWidth: 1000,
		innerHeight: 650
	});
	return new Task($win);
}
function Hardcore() {
	var $win = new $IframeWindow({
		src: "../../../../Games/2048/2048-Hardcore/index.html",
		icon: "Twenty",
		title: "2048 Hardcore",
		innerWidth: 500,
		innerHeight: 500
	});
	return new Task($win);
}
function Gore() {
	var $win = new $IframeWindow({
		src: "https://magnusgames.azurewebsites.net/GoreScript/index.html",
		icon: "Gore",
		title: "GoreScript Classic",
		innerWidth: 1000,
		innerHeight: 650
	});
	return new Task($win);
}

function SoundRecorder(file_path) {
	// TODO: DRY the default file names and title code (use document.title of the page in the iframe, in $IframeWindow)
	var document_title = file_path ? file_name_from_path(file_path) : "Sound";
	var win_title = document_title + " - Sound Recorder";
	// TODO: focus existing window if file is currently open?
	var $win = new $IframeWindow({
		src: "programs/sound-recorder/index.html" + (file_path ? ("?path=" + file_path) : ""),
		icon: "speaker",
		title: win_title,
		innerWidth: 270,
		innerHeight: 108
	});
	return new Task($win);
}
SoundRecorder.acceptsFilePaths = true;

function Explorer(address) {
	// TODO: DRY the default file names and title code (use document.title of the page in the iframe, in $IframeWindow)
	var document_title = address;
	var win_title = document_title;
	// TODO: focus existing window if folder is currently open
	var $win = new $IframeWindow({
		src: "programs/explorer/index.html" + (address ? ("?address=" + encodeURIComponent(address)) : ""),
		icon: "folder-open",
		title: win_title,
		innerWidth: 500,
		innerHeight: 500,
	});
	return new Task($win);
}
Explorer.acceptsFilePaths = true;

var webamp_bundle_loaded = false;
var load_winamp_bundle_if_not_loaded = function (includeButterchurn, callback) {
	// FIXME: webamp_bundle_loaded not actually set to true when loaded
	// TODO: also maybe handle already-loading-but-not-done
	if (webamp_bundle_loaded) {
		callback();
	} else {
		// TODO: paralellize (if possible)
		$.getScript("programs/winamp/lib/webamp.bundle.min.js", () => {
			if (includeButterchurn) {
				$.getScript("programs/winamp/lib/butterchurn.min.js", () => {
					$.getScript("programs/winamp/lib/butterchurnPresets.min.js", () => {
						callback();
					});
				});
			} else {
				callback();
			}
		});
	}
}

// from https://github.com/jberg/butterchurn/blob/master/src/isSupported.js
const isButterchurnSupported = () => {
	const canvas = document.createElement('canvas');
	let gl;
	try {
		gl = canvas.getContext('webgl2');
	} catch (x) {
		gl = null;
	}

	const webGL2Supported = !!gl;
	const audioApiSupported = !!(window.AudioContext || window.webkitAudioContext);

	return webGL2Supported && audioApiSupported;
};

let webamp;
let $webamp;
let winamp_task;
let winamp_interface;
let winamp_loading = false;
// TODO: support opening multiple files at once
function openWinamp(file_path) {
	const filePathToBlob = (file_path) => {
		return new Promise((resolve, reject) => {
			withFilesystem(function () {
				var fs = BrowserFS.BFSRequire("fs");
				fs.readFile(file_path, function (err, buffer) {
					if (err) {
						return reject(err);
					}
					const byte_array = new Uint8Array(buffer);
					const blob = new Blob([byte_array]);
					resolve(blob);
				});
			});
		});
	};

	const filePathToTrack = async (file_path) => {
		const blob = await filePathToBlob(file_path);
		const blob_url = URL.createObjectURL(blob);
		// TODO: revokeObjectURL
		const track = {
			url: blob_url,
			defaultName: file_name_from_path(file_path).replace(/\.[a-z0-9]+$/i, ""),
		};
		return track;
	};

	const whenLoaded = async () => {
		if ($webamp.css("display") === "none") {
			winamp_interface.unminimize();
		}

		winamp_interface.focus();

		if (file_path) {
			const track = await filePathToTrack(file_path);
			webamp.setTracksToPlay([track]);
		}

		winamp_loading = false;
	}
	if (winamp_task) {
		whenLoaded()
		return;
	}
	if (winamp_loading) {
		return; // TODO: queue up files?
	}
	winamp_loading = true;

	// This check creates a WebGL context, so don't do it if you try to open Winamp while it's opening or open.
	// (Otherwise it will lead to "WARNING: Too many active WebGL contexts. Oldest context will be lost.")
	const includeButterchurn = isButterchurnSupported();

	load_winamp_bundle_if_not_loaded(includeButterchurn, function () {
		const webamp_options = {
			initialTracks: [{
				metaData: {
					artist: "DJ Mike Llama",
					title: "Llama Whippin' Intro",
				},
				url: "programs/winamp/mp3/llama-2.91.mp3",
				duration: 5.322286,
			}],
			// initialSkin: {
			// 	url: "programs/winamp/skins/base-2.91.wsz",
			// },
			enableHotkeys: true,
			handleTrackDropEvent: (event) =>
				Promise.all(
					dragging_file_paths.map(filePathToTrack)
				),
			// TODO: filePickers
		};
		if (includeButterchurn) {
			webamp_options.__butterchurnOptions = {
				importButterchurn: () => Promise.resolve(window.butterchurn),
				getPresets: () => {
					const presets = window.butterchurnPresets.getPresets();
					return Object.keys(presets).map((name) => {
						return {
							name,
							butterchurnPresetObject: presets[name]
						};
					});
				},
				butterchurnOpen: true,
			};
			webamp_options.__initialWindowLayout = {
				main: { position: { x: 0, y: 0 } },
				equalizer: { position: { x: 0, y: 116 } },
				playlist: { position: { x: 0, y: 232 }, size: [0, 4] },
				milkdrop: { position: { x: 275, y: 0 }, size: [7, 12] }
			};
		}
		webamp = new Webamp(webamp_options);

		var visual_container = document.createElement("div");
		visual_container.classList.add("webamp-visual-container");
		visual_container.style.position = "absolute";
		visual_container.style.left = "0";
		visual_container.style.right = "0";
		visual_container.style.top = "0";
		visual_container.style.bottom = "0";
		visual_container.style.pointerEvents = "none";
		document.body.appendChild(visual_container);
		// Render after the skin has loaded.
		webamp.renderWhenReady(visual_container)
			.then(() => {
				window.console && console.log("Webamp rendered");

				$webamp = $("#webamp");
				// Bring window to front, initially and when clicked
				$webamp.css({
					position: "absolute",
					left: 0,
					top: 0,
					zIndex: $Window.Z_INDEX++
				});

				const $eventTarget = $({});
				const makeSimpleListenable = (name) => {
					return (callback) => {
						const fn = () => {
							callback();
						};
						$eventTarget.on(name, fn);
						const dispose = () => {
							$eventTarget.off(name, fn);
						};
						return dispose;
					};
				};

				winamp_interface = {};
				winamp_interface.onFocus = makeSimpleListenable("focus");
				winamp_interface.onBlur = makeSimpleListenable("blur");
				winamp_interface.onClosed = makeSimpleListenable("closed");
				winamp_interface.getIconName = () => "winamp2";
				winamp_interface.bringToFront = () => {
					$webamp.css({
						zIndex: $Window.Z_INDEX++
					});
				};
				winamp_interface.focus = () => {
					if (window.focusedWindow === winamp_interface) {
						return;
					}
					window.focusedWindow && focusedWindow.blur();
					winamp_interface.bringToFront();
					// TODO: trigger click?
					// on last focused winamp window
					$eventTarget.triggerHandler("focus");

					window.focusedWindow = winamp_interface;
				};
				winamp_interface.blur = () => {
					if (window.focusedWindow !== winamp_interface) {
						return;
					}
					// TODO
					$eventTarget.triggerHandler("blur");

					window.focusedWindow = null;
				};
				winamp_interface.minimize = () => {
					// TODO: are these actually useful or does webamp hide it?
					$webamp.hide();
				};
				winamp_interface.unminimize = () => {
					// more to the point does this work necsesarilyrdrfsF??
					$webamp.show();
					// $webamp.focus();
				};
				winamp_interface.close = () => {
					// not allowing canceling close event in this case (generally used *by* an application (for "Save changes?"), not outside of it)
					// TODO: probably something like winamp_task.close()
					// winamp_interface.triggerHandler("close");
					// winamp_interface.triggerHandler("closed");
					webamp.dispose();
					$webamp.remove();

					$eventTarget.triggerHandler("closed");

					webamp = null;
					$webamp = null;
					winamp_task = null;
					winamp_interface = null;
				};
				winamp_interface.getTitle = () => {
					let taskTitle = "Winamp 2.91";
					const $cell = $webamp.find(".playlist-track-titles .track-cell.current");
					if ($cell.length) {
						taskTitle = `${$cell.text()} - Winamp`;
						switch (webamp.getMediaStatus()) {
							case "STOPPED":
								taskTitle = `${taskTitle} [Stopped]`
								break;
							case "PAUSED":
								taskTitle = `${taskTitle} [Paused]`
								break;
						}
					}
					return taskTitle;
				};

				mustHaveMethods(winamp_interface, windowInterfaceMethods);

				let raf_id;
				let global_pointerdown;

				winamp_task = new Task(winamp_interface);
				webamp.onClose(function () {
					winamp_interface.close();
					cancelAnimationFrame(raf_id);
					visualizerOverlay.fadeOutAndCleanUp();
					$G.off("pointerdown", global_pointerdown);
				});
				webamp.onMinimize(function () {
					winamp_interface.minimize();
				});
				const updateTitle = (_trackInfo) => {
					const taskTitle = winamp_interface.getTitle();
					winamp_task.$task.find(".title").text(taskTitle)
				};
				webamp.onTrackDidChange(updateTitle);
				updateTitle();

				$webamp.on("pointerdown", () => {
					winamp_interface.focus();
				});
				// TODO: DRY
				$G.on("pointerdown", global_pointerdown = (e) => {
					if (
						e.target.closest("#webamp") !== $webamp[0] &&
						!e.target.closest(".taskbar")
					) {
						winamp_interface.blur();
					}
				});

				const visualizerOverlay = new VisualizerOverlay(
					$webamp.find(".gen-window canvas")[0],
					{ mirror: true, stretch: true },
				);

				// TODO: replace with setInterval
				// Note: can't access butterchurn canvas image data during a requestAnimationFrame here
				// because of double buffering
				const animate = () => {
					const windowElements = $(".os-window, .window:not(.gen-window)").toArray();
					windowElements.forEach(windowEl => {
						if (!windowEl.hasOverlayCanvas) {
							visualizerOverlay.makeOverlayCanvas(windowEl);
							windowEl.hasOverlayCanvas = true;
						}
					});

					if (webamp.getMediaStatus() === "PLAYING") {
						visualizerOverlay.fadeIn();
					} else {
						visualizerOverlay.fadeOut();
					}
					raf_id = requestAnimationFrame(animate);
				};
				raf_id = requestAnimationFrame(animate);

				whenLoaded()
			}, (error) => {
				// TODO: show_error_message("Failed to load Webamp:", error);
				alert("Failed to render Webamp:\n\n" + error);
				console.error(error);
			});
	});
}
openWinamp.acceptsFilePaths = true;

/*
function saveAsDialog(){
	var $win = new $Window();
	$win.title("Save As");
	return $win;
}
function openFileDialog(){
	var $win = new $Window();
	$win.title("Open");
	return $win;
}
*/

function openURLFile(file_path) {
	withFilesystem(function () {
		var fs = BrowserFS.BFSRequire("fs");
		fs.readFile(file_path, "utf8", function (err, content) {
			if (err) {
				return alert(err);
			}
			// it's supposed to be an ini-style file, but lets handle files that are literally just a URL as well, just in case
			var match = content.match(/URL\s*=\s*([^\n\r]+)/i);
			var url = match ? match[1] : content;
			Explorer(url);
		});
	});
}
openURLFile.acceptsFilePaths = true;

function openThemeFile(file_path) {
	withFilesystem(function () {
		var fs = BrowserFS.BFSRequire("fs");
		fs.readFile(file_path, "utf8", function (err, content) {
			if (err) {
				return alert(err);
			}
			loadThemeFromText(content);
		});
	});
}
openThemeFile.acceptsFilePaths = true;

var file_extension_associations = {
	"": Notepad,
	txt: Notepad,
	md: Notepad,
	json: Notepad,
	js: Notepad,
	css: Notepad,
	html: Notepad,
	gitattributes: Notepad,
	gitignore: Notepad,
	png: Paint,
	jpg: Paint,
	jpeg: Paint,
	gif: Paint,
	webp: Paint,
	bmp: Paint,
	tif: Paint,
	tiff: Paint,
	wav: SoundRecorder,
	mp3: openWinamp,
	ogg: openWinamp,
	wma: openWinamp,
	m4a: openWinamp,
	htm: Explorer,
	html: Explorer,
	url: openURLFile,
	theme: openThemeFile,
	themepack: openThemeFile,
};

// Note: global executeFile called by explorer
function executeFile(file_path) {
	// execute file with default handler
	// like the START command in CMD.EXE

	withFilesystem(function () {
		var fs = BrowserFS.BFSRequire("fs");
		fs.stat(file_path, function (err, stats) {
			if (err) {
				return alert("Failed to get info about " + file_path + "\n\n" + err);
			}
			if (stats.isDirectory()) {
				Explorer(file_path);
			} else {
				var file_extension = file_extension_from_path(file_path);
				var program = file_extension_associations[file_extension];
				if (program) {
					if (!program.acceptsFilePaths) {
						alert(program.name + " does not support opening files via the virtual filesystem yet");
						return;
					}
					program(file_path);
				} else {
					alert("No program is associated with " + file_extension + " files");
				}
			}
		});
	});
}

// TODO: base all the desktop icons off of the filesystem
// Note: `C:\Windows\Desktop` doesn't contain My Computer, My Documents, Network Neighborhood, Recycle Bin, or Internet Explorer,
// or Connect to the Internet, or Setup MSN Internet Access,
// whereas `Desktop` does (that's the full address it shows; it's one of them "special locations")
var add_icon_not_via_filesystem = function (options) {
	options.icon = $Icon(options.icon, DESKTOP_ICON_SIZE);
	new $FolderViewIcon(options).appendTo($folder_view);
};

add_icon_not_via_filesystem({
	title: "Paint",
	icon: "paint",
	open: Paint,

});
add_icon_not_via_filesystem({
	title: "Minesweeper",
	icon: "minesweeper",
	open: Minesweeper,

});
add_icon_not_via_filesystem({
	title: "Sound Recorder",
	icon: "speaker",
	open: SoundRecorder,

});
add_icon_not_via_filesystem({
	title: "Solitare",
	icon: "Solitare",
	open: Solitare,

});
add_icon_not_via_filesystem({
	title: "Notepad",
	icon: "notepad",
	open: Notepad,

});
add_icon_not_via_filesystem({
	title: "Winamp",
	icon: "winamp2",
	open: openWinamp,

});
add_icon_not_via_filesystem({
	title: "MS-CMD",
	icon: "DOS",
	open: MSCMD,

});
add_icon_not_via_filesystem({
	title: "Google",
	icon: "chrome",
	open: google,

});
add_icon_not_via_filesystem({
	title: "Network Neighborhood",
	icon: "Network",
	open: Network,

});
add_icon_not_via_filesystem({
	title: "Nyan Browser",
	icon: "nyan",
	open: nyan,

});
add_icon_not_via_filesystem({
	title: "Youtube",
	icon: "Youtube",
	open: U2,

});
add_icon_not_via_filesystem({
	title: "TikTok",
	icon: "tiktok",
	open: tiktok,

});
add_icon_not_via_filesystem({
	title: "English Pricks",
	icon: "Chat",
	open: Chat,

});
add_icon_not_via_filesystem({
	title: "2048",
	icon: "Twenty",
	open: Fourty,

});
add_icon_not_via_filesystem({
	title: "Cookie Clicker",
	icon: "Cookie",
	open: Cookie,

});
add_icon_not_via_filesystem({
	title: "Chrome Dino",
	icon: "Dino",
	open: Dino,

});
add_icon_not_via_filesystem({
	title: "Brain Games",
	icon: "Brain",
	open: Brain,

});
add_icon_not_via_filesystem({
	title: "Classic Arcade Games",
	icon: "Classics",
	open: Classics,

});
add_icon_not_via_filesystem({
	title: "Mario Games",
	icon: "Mario",
	open: Mario,

});
add_icon_not_via_filesystem({
	title: "Minecraft",
	icon: "Minecraft",
	open: Minecraft,

});
add_icon_not_via_filesystem({
	title: "There is No Game",
	icon: "NoGame",
	open: NoGame,

});
add_icon_not_via_filesystem({
	title: "Power Player Super Joy III",
	icon: "Power",
	open: Power,

});
add_icon_not_via_filesystem({
	title: "Rioluvania",
	icon: "Rioluvania",
	open: Rioluvania,
});
add_icon_not_via_filesystem({
	title: "The Binding of Isaac",
	icon: "TBOI",
	open: TBOI,

});

add_icon_not_via_filesystem({
	title: "Rocket Custa",
	icon: "Rocket",
	open: Rocket,

});
add_icon_not_via_filesystem({
	title: "Spelunky",
	icon: "Spelunky",
	open: Spelunky,

});
add_icon_not_via_filesystem({
	title: "Gameboy Emulator",
	icon: "Atlantis",
	open: Atlantis,

});
add_icon_not_via_filesystem({
	title: "Mircosoft Surf",
	icon: "Surf",
	open: Surf,

});
add_icon_not_via_filesystem({
	title: "Ice Dodo",
	icon: "Ice",
	open: Ice,

});
add_icon_not_via_filesystem({
	title: "Hex GL",
	icon: "Hex",
	open: Hex,

});
add_icon_not_via_filesystem({
	title: "Credits.txt",
	icon: "File",
	open: Credit,
	shortcut: true
});
add_icon_not_via_filesystem({
	title: "Windows 95",
	icon: "95",
	open: Nine,

});
add_icon_not_via_filesystem({
	title: "GoreScript Classic",
	icon: "Gore",
	open: Gore,

});
add_icon_not_via_filesystem({
	title: "Ultimate Doom",
	icon: "Doom",
	open: Doom,

});
add_icon_not_via_filesystem({
	title: "Doom 2",
	icon: "Doom_2",
	open: Doom2,

});
add_icon_not_via_filesystem({
	title: "The Ultimate Doom 2",
	icon: "UD2",
	open: UD2,

});
add_icon_not_via_filesystem({
	title: "The Master Levels for Doom 2",
	icon: "Master",
	open: Master,

});
add_icon_not_via_filesystem({
	title: "Brutal Doom 2",
	icon: "BDoom",
	open: BDoom2,

});
add_icon_not_via_filesystem({
	title: "Doom 4",
	icon: "4",
	open: div11,

});
add_icon_not_via_filesystem({
	title: "Duke Nukem 3D",
	icon: "Duke",
	open: Duke,

});
add_icon_not_via_filesystem({
	title: "Grand Theft Auto",
	icon: "GTA",
	open: GTA,

});
add_icon_not_via_filesystem({
	title: "The Deluxe Oregon Trail",
	icon: "Oregon",
	open: DTrail,

});
add_icon_not_via_filesystem({
	title: "Oregon Trail",
	icon: "Trail",
	open: Trail,

});
add_icon_not_via_filesystem({
	title: "Castle Wolfenstien",
	icon: "Castle",
	open: Castle,

});
add_icon_not_via_filesystem({
	title: "Heretic",
	icon: "Heretic",
	open: Heretic,

});
add_icon_not_via_filesystem({
	title: "Heretic 2",
	icon: "Heretic2",
	open: Heretic2,

});
add_icon_not_via_filesystem({
	title: "Hexen",
	icon: "Hexen",
	open: Hexen,

});
add_icon_not_via_filesystem({
	title: "Plutonia",
	icon: "Plutonia",
	open: Plutonia,

});
add_icon_not_via_filesystem({
	title: "Plutonia 2",
	icon: "Plutonia2",
	open: Plutonia2,

});
add_icon_not_via_filesystem({
	title: "TNT",
	icon: "FDoom",
	open: TNT,

});
add_icon_not_via_filesystem({
	title: "Doom64",
	icon: "64",
	open: Sixty,

});
add_icon_not_via_filesystem({
	title: "Doom Zero",
	icon: "Zero",
	open: Zero,
});

add_icon_not_via_filesystem({
	title: "Batman Doom",
	icon: "Batman",
	open: BatDoom,
});

add_icon_not_via_filesystem({
	title: "Star Wars Doom",
	icon: "SDoom",
	open: StarDoom,
});

add_icon_not_via_filesystem({
	title: "Quake",
	icon: "Quake",
	open: Quake,

});
add_icon_not_via_filesystem({
	title: "Quake 2",
	icon: "Quake2",
	open: Quake2,

});
add_icon_not_via_filesystem({
	title: "Spear",
	icon: "Spear",
	open: Spear,

});
add_icon_not_via_filesystem({
	title: "Strife",
	icon: "Strife",
	open: Strife,

});
add_icon_not_via_filesystem({
	title: "FreeDoom",
	icon: "FreeDoom",
	open: div12,

});
add_icon_not_via_filesystem({
	title: "Wolf 3D",
	icon: "Wolf_3d",
	open: Wolf3D,

});
add_icon_not_via_filesystem({
	title: "Back to Saturn X",
	icon: "BTSX",
	open: BTSX,

});
add_icon_not_via_filesystem({
	title: "Back to Saturn X 2",
	icon: "BTSX",
	open: BTSX2,

});
add_icon_not_via_filesystem({
	title: "Chex Quest 1",
	icon: "Chex",
	open: Chex1,

});
add_icon_not_via_filesystem({
	title: "Chex Quest 2",
	icon: "Chex2",
	open: Chex2,

});
add_icon_not_via_filesystem({
	title: "Chex Quest 3",
	icon: "Chex3",
	open: Chex3,

});
add_icon_not_via_filesystem({
	title: "Doom 2D",
	icon: "2D",
	open: Doom2D,

});
add_icon_not_via_filesystem({
	title: "Mario Doom",
	icon: "Dario",
	open: Dario1,

});
add_icon_not_via_filesystem({
	title: "Mario Doom 2",
	icon: "Dario",
	open: Dario2,

});
add_icon_not_via_filesystem({
	title: "Procrastination Button",
	icon: "Button",
	open: Button,

});
add_icon_not_via_filesystem({
	title: "Clock",
	icon: "Clock",
	open: Clock,

});
add_icon_not_via_filesystem({
	title: "DVD Screensaver",
	icon: "DVD",
	open: DVD,

});
add_icon_not_via_filesystem({
	title: "Matrix Screensaver",
	icon: "Matrix",
	open: Matrix,

});
add_icon_not_via_filesystem({
	title: "Fluid Simulator",
	icon: "Fluid",
	open: Fluid,

});
add_icon_not_via_filesystem({
	title: "Vending Machine",
	icon: "Soda",
	open: Soda,

});
add_icon_not_via_filesystem({
	title: "Star Wars Episode IV",
	icon: "Starwars",
	open: Star,

});
// add_icon_not_via_filesystem({
// 	title: "Pinball",
// 	icon: "Pinball",
// 	open: Pinball,

// });

$folder_view.arrange_icons();