# note
Basically every thing is done in browser locally, so any server will work to server those assets in [Public](./public), But whats important is that assets should be compressed (gzipped) or otherwise it will take long times to load page.
