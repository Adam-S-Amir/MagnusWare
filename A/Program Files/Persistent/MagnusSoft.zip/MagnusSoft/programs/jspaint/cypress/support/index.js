// ***********************************************************
// This support/index.js is processed and
// loaded automatically before your test files.
//
// https://on.cypress.io/configuration

import './commands'
