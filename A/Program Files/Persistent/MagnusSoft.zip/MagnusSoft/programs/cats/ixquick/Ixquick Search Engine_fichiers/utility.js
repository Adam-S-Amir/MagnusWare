var arVersion = navigator.appVersion.split("MSIE");
var version = parseFloat(arVersion[1]);
var chldTag = "img";
var dsplay = "";
if (version >= 5.5 && version < 7) {
    chldTag = "span";
    dsplay = "inline-block"
}
function lightOnOff(f, d, c) {
    if (version >= 5.5 && version < 7) {
        if (d && f.getElementsByTagName(chldTag).item(0).outerHTML.match(/hover/)) {
            return
        }
        if (!d && !f.getElementsByTagName(chldTag).item(0).outerHTML.match(/hover/)) {
            return
        }
    } else {
        if (d && f.getElementsByTagName(chldTag).item(0).src.match(/hover/)) {
            return
        }
        if (!d && !f.getElementsByTagName(chldTag).item(0).src.match(/hover/)) {
            return
        }
    }
    var e = f.getElementsByTagName(chldTag).item(0);
    if (version >= 5.5 && version < 7) {
        if (d) {
            if (c.match(/hover_basic/)) {
                var b = document.getElementById("lighton3").cloneNode(true)
            } else {
                var b = document.getElementById("lighton").cloneNode(true)
            }
            b.style.display = dsplay;
            b.style.width = "210px";
            b.style.height = "61px";
            f.replaceChild(b, e)
        } else {
            var a = document.getElementById("lighton").cloneNode(true);
            a.style.display = dsplay;
            a.style.width = "210px";
            a.style.height = "61px";
            f.replaceChild(a, e)
        }
        f.getElementsByTagName(chldTag).item(0).id = "li"
    } else {
        if (d) {
            f.getElementsByTagName(chldTag).item(0).src = c
        } else {
            f.getElementsByTagName(chldTag).item(0).src = c
        }
    }
    return true
}
function change_theme(h, g) {
    var b = document.URL;
    if (b.indexOf("ixquick.nl/") != -1) {
        g = "ixquick.nl"
    } else {
        if (b.indexOf("ixquick.be/") != -1) {
            g = "ixquick.be"
        } else {
            if (b.indexOf("ixquick.de/") != -1) {
                g = "ixquick.de"
            } else {
                if (b.indexOf("ixquick.it/") != -1) {
                    g = "ixquick.it"
                } else {
                    if (b.indexOf("ixquick.eu/") != -1) {
                        g = "ixquick.eu"
                    } else {
                        if (b.indexOf("ixquick.es/") != -1) {
                            g = "ixquick.es"
                        } else {
                            if (b.indexOf("ixquick.fr/") != -1) {
                                g = "ixquick.fr"
                            } else {
                                if (b.indexOf("ixquick.asia/") != -1) {
                                    g = "ixquick.asia"
                                } else {
                                    if (b.indexOf("ixquick.co.uk/") != -1) {
                                        g = "ixquick.co.uk"
                                    } else {
                                        if (b.indexOf("xquick.be/") != -1) {
                                            g = "xquick.be"
                                        } else {
                                            if (b.indexOf("xquick.nl/") != -1) {
                                                g = "xquick.nl"
                                            } else {
                                                if (b.indexOf("xquick.cn/") != -1) {
                                                    g = "xquick.cn"
                                                } else {
                                                    if (b.indexOf("xquick.it/") != -1) {
                                                        g = "xquick.it"
                                                    } else {
                                                        if (b.indexOf("xquick.es/") != -1) {
                                                            g = "xquick.es"
                                                        } else {
                                                            if (b.indexOf("xquick.eu/") != -1) {
                                                                g = "xquick.fr"
                                                            } else {
                                                                if (b.indexOf("xquick.fr/") != -1) {
                                                                    g = "xquick.fr"
                                                                } else {
                                                                    if (b.indexOf("xquick.asia/") != -1) {
                                                                        g = "xquick.asia"
                                                                    } else {
                                                                        if (b.indexOf("xquick.co.uk/") != -1) {
                                                                            g = "xquick.co.uk"
                                                                        } else {
                                                                            if (b.indexOf("surfboard.nl/") != -1) {
                                                                                g = "surfboard.nl"
                                                                            } else {
                                                                                if (b.indexOf("surfboard.eu/") != -1) {
                                                                                    g = "surfboard.eu"
                                                                                } else {
                                                                                    if (b.indexOf("ix-quick.nl/") != -1) {
                                                                                        g = "ix-quick.nl"
                                                                                    } else {
                                                                                        if (b.indexOf("ix-quick.de/") != -1) {
                                                                                            g = "ix-quick.de"
                                                                                        } else {
                                                                                            if (b.indexOf("ix-quick.cn/") != -1) {
                                                                                                g = "ix-quick.cn"
                                                                                            } else {
                                                                                                if (b.indexOf("ix-quick.eu/") != -1) {
                                                                                                    g = "ix-quick.eu"
                                                                                                } else {
                                                                                                    if (b.indexOf("baldie.nl/") != -1) {
                                                                                                        g = "baldie.nl"
                                                                                                    } else {
                                                                                                        if (b.indexOf("9quick.com/") != -1) {
                                                                                                            g = "9quick.com"
                                                                                                        } else {
                                                                                                            if (b.indexOf("9-quick.cn/") != -1) {
                                                                                                                g = "9-quick.cn"
                                                                                                            } else {
                                                                                                                if (b.indexOf("9quick.cn/") != -1) {
                                                                                                                    g = "9quick.cn"
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    var d = "";
    var m = 0;
    if (GetCookie("preferences")) {
        var o = GetCookie("preferences");
        a = o.split("N1N");
        d = "";
        for (i = 0; i < a.length; i++) {
            if (a[i].indexOf("lang_homepage") != -1) {
                d = a[i]
            } else {
                if (a[i].indexOf("num_of_results") != -1) {
                    m = 1
                }
            }
        }
    }
    var l = "";
    if (d != "") {
        var f = d.split("EEE");
        if (f[1].indexOf("s/") != -1) {
            var n = f[1].split("/");
            if (h != "") {
                n[1] = h;
                for (var e = 0; e < n.length; e++) {
                    l += n[e];
                    if ((e + 1) < n.length) {
                        l += "/"
                    }
                }
            } else {
                for (var e = 2; e < n.length; e++) {
                    l += n[e];
                    if ((e + 1) < n.length) {
                        l += "/"
                    }
                }
            }
        } else {
            if (h != "") {
                l = "s/" + h + "/" + f[1]
            }
        }
    } else {
        if (h != "") {
            l = "s/" + h + "/"
        }
    }
    if (l != "") {
        l = "lang_homepageEEE" + l;
        var k = "";
        if (GetCookie("preferences")) {
            var o = GetCookie("preferences");
            var a = o.split("N1N");
            for (i = 0; i < a.length; i++) {
                if (a[i].indexOf("lang_homepage") != -1) {} else {
                    if (a[i] != "") {
                        k += a[i] + "N1N"
                    }
                }
            }
            k += l + "N1N"
        } else {
            k = l + "N1N"
        }
        var c = new Date();
        c.setDate(c.getDate() + 90);
        SetCookie("preferences", k, c, "/", g)
    } else {
        if (GetCookie("preferences")) {
            var o = GetCookie("preferences");
            var a = o.split("N1N");
            var k = "";
            for (i = 0; i < a.length; i++) {
                if (a[i].indexOf("lang_homepage") != -1) {} else {
                    k += a[i] + "N1N"
                }
            }
            var c = new Date();
            c.setDate(c.getDate() + 90);
            if (k != "") {
                SetCookie("preferences", k, c, "/", g)
            }
        }
    }
    if ((m == 0) && (l == "")) {
        var c = new Date(2001,11,1);
        SetCookie("preferences", "", c, "/", g)
    }
    return true
}
;