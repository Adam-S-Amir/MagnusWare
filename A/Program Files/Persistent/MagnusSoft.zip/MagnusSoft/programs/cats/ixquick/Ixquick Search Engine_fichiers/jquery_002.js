/*! Hammer.JS - v1.0.5 - 2013-04-07
 * http://eightmedia.github.com/hammer.js
 *
 * Copyright (c) 2013 Jorik Tangelder <j.tangelder@gmail.com>;
 * Licensed under the MIT license */
(function(b, f) {
    function h() {
        if (!a.READY) {
            a.event.determineEventTypes();
            for (var e in a.gestures) {
                a.gestures.hasOwnProperty(e) && a.detection.register(a.gestures[e])
            }
            a.event.onTouch(a.DOCUMENT, a.EVENT_MOVE, a.detection.detect),
            a.event.onTouch(a.DOCUMENT, a.EVENT_END, a.detection.detect),
            a.READY = !0
        }
    }
    var a = function(i, j) {
        return new a.Instance(i,j || {})
    };
    a.defaults = {
        stop_browser_behavior: {
            userSelect: "none",
            touchAction: "none",
            touchCallout: "none",
            contentZooming: "none",
            userDrag: "none",
            tapHighlightColor: "rgba(0,0,0,0)"
        }
    },
    a.HAS_POINTEREVENTS = navigator.pointerEnabled || navigator.msPointerEnabled,
    a.HAS_TOUCHEVENTS = "ontouchstart"in b,
    a.MOBILE_REGEX = /mobile|tablet|ip(ad|hone|od)|android/i,
    a.NO_MOUSEEVENTS = a.HAS_TOUCHEVENTS && navigator.userAgent.match(a.MOBILE_REGEX),
    a.EVENT_TYPES = {},
    a.DIRECTION_DOWN = "down",
    a.DIRECTION_LEFT = "left",
    a.DIRECTION_UP = "up",
    a.DIRECTION_RIGHT = "right",
    a.POINTER_MOUSE = "mouse",
    a.POINTER_TOUCH = "touch",
    a.POINTER_PEN = "pen",
    a.EVENT_START = "start",
    a.EVENT_MOVE = "move",
    a.EVENT_END = "end",
    a.DOCUMENT = document,
    a.plugins = {},
    a.READY = !1,
    a.Instance = function(i, k) {
        var j = this;
        return h(),
        this.element = i,
        this.enabled = !0,
        this.options = a.utils.extend(a.utils.extend({}, a.defaults), k || {}),
        this.options.stop_browser_behavior && a.utils.stopDefaultBrowserBehavior(this.element, this.options.stop_browser_behavior),
        a.event.onTouch(i, a.EVENT_START, function(e) {
            j.enabled && a.detection.startDetect(j, e)
        }),
        this
    }
    ,
    a.Instance.prototype = {
        on: function(k, l) {
            for (var m = k.split(" "), j = 0; m.length > j; j++) {
                this.element.addEventListener(m[j], l, !1)
            }
            return this
        },
        off: function(k, l) {
            for (var m = k.split(" "), j = 0; m.length > j; j++) {
                this.element.removeEventListener(m[j], l, !1)
            }
            return this
        },
        trigger: function(i, k) {
            var l = a.DOCUMENT.createEvent("Event");
            l.initEvent(i, !0, !0),
            l.gesture = k;
            var j = this.element;
            return a.utils.hasParent(k.target, j) && (j = k.target),
            j.dispatchEvent(l),
            this
        },
        enable: function(e) {
            return this.enabled = e,
            this
        }
    };
    var d = null
      , g = !1
      , c = !1;
    a.event = {
        bindDom: function(k, m, o) {
            for (var j = m.split(" "), l = 0; j.length > l; l++) {
                k.addEventListener(j[l], o, !1)
            }
        },
        onTouch: function(j, k, l) {
            var i = this;
            this.bindDom(j, a.EVENT_TYPES[k], function(n) {
                var e = n.type.toLowerCase();
                if (!e.match(/mouse/) || !c) {
                    (e.match(/touch/) || e.match(/pointerdown/) || e.match(/mouse/) && 1 === n.which) && (g = !0),
                    e.match(/touch|pointer/) && (c = !0);
                    var m = 0;
                    g && (a.HAS_POINTEREVENTS && k != a.EVENT_END ? m = a.PointerEvent.updatePointer(k, n) : e.match(/touch/) ? m = n.touches.length : c || (m = e.match(/up/) ? 0 : 1),
                    m > 0 && k == a.EVENT_END ? k = a.EVENT_MOVE : m || (k = a.EVENT_END),
                    m || null === d ? d = n : n = d,
                    l.call(a.detection, i.collectEventData(j, k, n)),
                    a.HAS_POINTEREVENTS && k == a.EVENT_END && (m = a.PointerEvent.updatePointer(k, n))),
                    m || (d = null,
                    g = !1,
                    c = !1,
                    a.PointerEvent.reset())
                }
            })
        },
        determineEventTypes: function() {
            var e;
            e = a.HAS_POINTEREVENTS ? a.PointerEvent.getEvents() : a.NO_MOUSEEVENTS ? ["touchstart", "touchmove", "touchend touchcancel"] : ["touchstart mousedown", "touchmove mousemove", "touchend touchcancel mouseup"],
            a.EVENT_TYPES[a.EVENT_START] = e[0],
            a.EVENT_TYPES[a.EVENT_MOVE] = e[1],
            a.EVENT_TYPES[a.EVENT_END] = e[2]
        },
        getTouchList: function(e) {
            return a.HAS_POINTEREVENTS ? a.PointerEvent.getTouchList() : e.touches ? e.touches : [{
                identifier: 1,
                pageX: e.pageX,
                pageY: e.pageY,
                target: e.target
            }]
        },
        collectEventData: function(i, k, m) {
            var j = this.getTouchList(m, k)
              , l = a.POINTER_TOUCH;
            return (m.type.match(/mouse/) || a.PointerEvent.matchType(a.POINTER_MOUSE, m)) && (l = a.POINTER_MOUSE),
            {
                center: a.utils.getCenter(j),
                timeStamp: (new Date).getTime(),
                target: m.target,
                touches: j,
                eventType: k,
                pointerType: l,
                srcEvent: m,
                preventDefault: function() {
                    this.srcEvent.preventManipulation && this.srcEvent.preventManipulation(),
                    this.srcEvent.preventDefault && this.srcEvent.preventDefault()
                },
                stopPropagation: function() {
                    this.srcEvent.stopPropagation()
                },
                stopDetect: function() {
                    return a.detection.stopDetect()
                }
            }
        }
    },
    a.PointerEvent = {
        pointers: {},
        getTouchList: function() {
            var i = this
              , j = [];
            return Object.keys(i.pointers).sort().forEach(function(e) {
                j.push(i.pointers[e])
            }),
            j
        },
        updatePointer: function(i, j) {
            return i == a.EVENT_END ? this.pointers = {} : (j.identifier = j.pointerId,
            this.pointers[j.pointerId] = j),
            Object.keys(this.pointers).length
        },
        matchType: function(i, j) {
            if (!j.pointerType) {
                return !1
            }
            var k = {};
            return k[a.POINTER_MOUSE] = j.pointerType == j.MSPOINTER_TYPE_MOUSE || j.pointerType == a.POINTER_MOUSE,
            k[a.POINTER_TOUCH] = j.pointerType == j.MSPOINTER_TYPE_TOUCH || j.pointerType == a.POINTER_TOUCH,
            k[a.POINTER_PEN] = j.pointerType == j.MSPOINTER_TYPE_PEN || j.pointerType == a.POINTER_PEN,
            k[i]
        },
        getEvents: function() {
            return ["pointerdown MSPointerDown", "pointermove MSPointerMove", "pointerup pointercancel MSPointerUp MSPointerCancel"]
        },
        reset: function() {
            this.pointers = {}
        }
    },
    a.utils = {
        extend: function(j, l, e) {
            for (var k in l) {
                j[k] !== f && e || (j[k] = l[k])
            }
            return j
        },
        hasParent: function(i, j) {
            for (; i; ) {
                if (i == j) {
                    return !0
                }
                i = i.parentNode
            }
            return !1
        },
        getCenter: function(k) {
            for (var m = [], o = [], j = 0, l = k.length; l > j; j++) {
                m.push(k[j].pageX),
                o.push(k[j].pageY)
            }
            return {
                pageX: (Math.min.apply(Math, m) + Math.max.apply(Math, m)) / 2,
                pageY: (Math.min.apply(Math, o) + Math.max.apply(Math, o)) / 2
            }
        },
        getVelocity: function(i, j, k) {
            return {
                x: Math.abs(j / i) || 0,
                y: Math.abs(k / i) || 0
            }
        },
        getAngle: function(k, l) {
            var m = l.pageY - k.pageY
              , j = l.pageX - k.pageX;
            return 180 * Math.atan2(m, j) / Math.PI
        },
        getDirection: function(i, k) {
            var l = Math.abs(i.pageX - k.pageX)
              , j = Math.abs(i.pageY - k.pageY);
            return l >= j ? i.pageX - k.pageX > 0 ? a.DIRECTION_LEFT : a.DIRECTION_RIGHT : i.pageY - k.pageY > 0 ? a.DIRECTION_UP : a.DIRECTION_DOWN
        },
        getDistance: function(k, l) {
            var m = l.pageX - k.pageX
              , j = l.pageY - k.pageY;
            return Math.sqrt(m * m + j * j)
        },
        getScale: function(i, j) {
            return i.length >= 2 && j.length >= 2 ? this.getDistance(j[0], j[1]) / this.getDistance(i[0], i[1]) : 1
        },
        getRotation: function(i, j) {
            return i.length >= 2 && j.length >= 2 ? this.getAngle(j[1], j[0]) - this.getAngle(i[1], i[0]) : 0
        },
        isVertical: function(e) {
            return e == a.DIRECTION_UP || e == a.DIRECTION_DOWN
        },
        stopDefaultBrowserBehavior: function(k, m) {
            var q, j = ["webkit", "khtml", "moz", "ms", "o", ""];
            if (m && k.style) {
                for (var l = 0; j.length > l; l++) {
                    for (var p in m) {
                        m.hasOwnProperty(p) && (q = p,
                        j[l] && (q = j[l] + q.substring(0, 1).toUpperCase() + q.substring(1)),
                        k.style[q] = m[p])
                    }
                }
                "none" == m.userSelect && (k.onselectstart = function() {
                    return !1
                }
                )
            }
        }
    },
    a.detection = {
        gestures: [],
        current: null,
        previous: null,
        stopped: !1,
        startDetect: function(i, j) {
            this.current || (this.stopped = !1,
            this.current = {
                inst: i,
                startEvent: a.utils.extend({}, j),
                lastEvent: !1,
                name: ""
            },
            this.detect(j))
        },
        detect: function(i) {
            if (this.current && !this.stopped) {
                i = this.extendEventData(i);
                for (var k = this.current.inst.options, m = 0, j = this.gestures.length; j > m; m++) {
                    var l = this.gestures[m];
                    if (!this.stopped && k[l.name] !== !1 && l.handler.call(l, i, this.current.inst) === !1) {
                        this.stopDetect();
                        break
                    }
                }
                return this.current && (this.current.lastEvent = i),
                i.eventType == a.EVENT_END && !i.touches.length - 1 && this.stopDetect(),
                i
            }
        },
        stopDetect: function() {
            this.previous = a.utils.extend({}, this.current),
            this.current = null,
            this.stopped = !0
        },
        extendEventData: function(j) {
            var m = this.current.startEvent;
            if (m && (j.touches.length != m.touches.length || j.touches === m.touches)) {
                m.touches = [];
                for (var u = 0, l = j.touches.length; l > u; u++) {
                    m.touches.push(a.utils.extend({}, j.touches[u]))
                }
            }
            var p = j.timeStamp - m.timeStamp
              , k = j.center.pageX - m.center.pageX
              , i = j.center.pageY - m.center.pageY
              , q = a.utils.getVelocity(p, k, i);
            return a.utils.extend(j, {
                deltaTime: p,
                deltaX: k,
                deltaY: i,
                velocityX: q.x,
                velocityY: q.y,
                distance: a.utils.getDistance(m.center, j.center),
                angle: a.utils.getAngle(m.center, j.center),
                direction: a.utils.getDirection(m.center, j.center),
                scale: a.utils.getScale(m.touches, j.touches),
                rotation: a.utils.getRotation(m.touches, j.touches),
                startEvent: m
            }),
            j
        },
        register: function(e) {
            var i = e.defaults || {};
            return i[e.name] === f && (i[e.name] = !0),
            a.utils.extend(a.defaults, i, !0),
            e.index = e.index || 1000,
            this.gestures.push(e),
            this.gestures.sort(function(j, k) {
                return j.index < k.index ? -1 : j.index > k.index ? 1 : 0
            }),
            this.gestures
        }
    },
    a.gestures = a.gestures || {},
    a.gestures.Hold = {
        name: "hold",
        index: 10,
        defaults: {
            hold_timeout: 500,
            hold_threshold: 1
        },
        timer: null,
        handler: function(i, j) {
            switch (i.eventType) {
            case a.EVENT_START:
                clearTimeout(this.timer),
                a.detection.current.name = this.name,
                this.timer = setTimeout(function() {
                    "hold" == a.detection.current.name && j.trigger("hold", i)
                }, j.options.hold_timeout);
                break;
            case a.EVENT_MOVE:
                i.distance > j.options.hold_threshold && clearTimeout(this.timer);
                break;
            case a.EVENT_END:
                clearTimeout(this.timer)
            }
        }
    },
    a.gestures.Tap = {
        name: "tap",
        index: 100,
        defaults: {
            tap_max_touchtime: 250,
            tap_max_distance: 10,
            tap_always: !0,
            doubletap_distance: 20,
            doubletap_interval: 300
        },
        handler: function(i, k) {
            if (i.eventType == a.EVENT_END) {
                var l = a.detection.previous
                  , j = !1;
                if (i.deltaTime > k.options.tap_max_touchtime || i.distance > k.options.tap_max_distance) {
                    return
                }
                l && "tap" == l.name && i.timeStamp - l.lastEvent.timeStamp < k.options.doubletap_interval && i.distance < k.options.doubletap_distance && (k.trigger("doubletap", i),
                j = !0),
                (!j || k.options.tap_always) && (a.detection.current.name = "tap",
                k.trigger(a.detection.current.name, i))
            }
        }
    },
    a.gestures.Swipe = {
        name: "swipe",
        index: 40,
        defaults: {
            swipe_max_touches: 1,
            swipe_velocity: 0.7
        },
        handler: function(i, j) {
            if (i.eventType == a.EVENT_END) {
                if (j.options.swipe_max_touches > 0 && i.touches.length > j.options.swipe_max_touches) {
                    return
                }
                (i.velocityX > j.options.swipe_velocity || i.velocityY > j.options.swipe_velocity) && (j.trigger(this.name, i),
                j.trigger(this.name + i.direction, i))
            }
        }
    },
    a.gestures.Drag = {
        name: "drag",
        index: 50,
        defaults: {
            drag_min_distance: 10,
            drag_max_touches: 1,
            drag_block_horizontal: !1,
            drag_block_vertical: !1,
            drag_lock_to_axis: !1,
            drag_lock_min_distance: 25
        },
        triggered: !1,
        handler: function(e, j) {
            if (a.detection.current.name != this.name && this.triggered) {
                return j.trigger(this.name + "end", e),
                this.triggered = !1,
                f
            }
            if (!(j.options.drag_max_touches > 0 && e.touches.length > j.options.drag_max_touches)) {
                switch (e.eventType) {
                case a.EVENT_START:
                    this.triggered = !1;
                    break;
                case a.EVENT_MOVE:
                    if (e.distance < j.options.drag_min_distance && a.detection.current.name != this.name) {
                        return
                    }
                    a.detection.current.name = this.name,
                    (a.detection.current.lastEvent.drag_locked_to_axis || j.options.drag_lock_to_axis && j.options.drag_lock_min_distance <= e.distance) && (e.drag_locked_to_axis = !0);
                    var i = a.detection.current.lastEvent.direction;
                    e.drag_locked_to_axis && i !== e.direction && (e.direction = a.utils.isVertical(i) ? 0 > e.deltaY ? a.DIRECTION_UP : a.DIRECTION_DOWN : 0 > e.deltaX ? a.DIRECTION_LEFT : a.DIRECTION_RIGHT),
                    this.triggered || (j.trigger(this.name + "start", e),
                    this.triggered = !0),
                    j.trigger(this.name, e),
                    j.trigger(this.name + e.direction, e),
                    (j.options.drag_block_vertical && a.utils.isVertical(e.direction) || j.options.drag_block_horizontal && !a.utils.isVertical(e.direction)) && e.preventDefault();
                    break;
                case a.EVENT_END:
                    this.triggered && j.trigger(this.name + "end", e),
                    this.triggered = !1
                }
            }
        }
    },
    a.gestures.Transform = {
        name: "transform",
        index: 45,
        defaults: {
            transform_min_scale: 0.01,
            transform_min_rotation: 1,
            transform_always_block: !1
        },
        triggered: !1,
        handler: function(e, k) {
            if (a.detection.current.name != this.name && this.triggered) {
                return k.trigger(this.name + "end", e),
                this.triggered = !1,
                f
            }
            if (!(2 > e.touches.length)) {
                switch (k.options.transform_always_block && e.preventDefault(),
                e.eventType) {
                case a.EVENT_START:
                    this.triggered = !1;
                    break;
                case a.EVENT_MOVE:
                    var i = Math.abs(1 - e.scale)
                      , j = Math.abs(e.rotation);
                    if (k.options.transform_min_scale > i && k.options.transform_min_rotation > j) {
                        return
                    }
                    a.detection.current.name = this.name,
                    this.triggered || (k.trigger(this.name + "start", e),
                    this.triggered = !0),
                    k.trigger(this.name, e),
                    j > k.options.transform_min_rotation && k.trigger("rotate", e),
                    i > k.options.transform_min_scale && (k.trigger("pinch", e),
                    k.trigger("pinch" + (1 > e.scale ? "in" : "out"), e));
                    break;
                case a.EVENT_END:
                    this.triggered && k.trigger(this.name + "end", e),
                    this.triggered = !1
                }
            }
        }
    },
    a.gestures.Touch = {
        name: "touch",
        index: -1 / 0,
        defaults: {
            prevent_default: !1,
            prevent_mouseevents: !1
        },
        handler: function(e, i) {
            return i.options.prevent_mouseevents && e.pointerType == a.POINTER_MOUSE ? (e.stopDetect(),
            f) : (i.options.prevent_default && e.preventDefault(),
            e.eventType == a.EVENT_START && i.trigger(this.name, e),
            f)
        }
    },
    a.gestures.Release = {
        name: "release",
        index: 1 / 0,
        handler: function(i, j) {
            i.eventType == a.EVENT_END && j.trigger(this.name, i)
        }
    },
    "object" == typeof module && "object" == typeof module.exports ? module.exports = a : (b.Hammer = a,
    "function" == typeof b.define && b.define.amd && b.define("hammer", [], function() {
        return a
    }))
}
)(this),
function(a, b) {
    a !== b && (Hammer.event.bindDom = function(e, c, d) {
        a(e).on(c, function(f) {
            var g = f.originalEvent || f;
            g.pageX === b && (g.pageX = f.pageX,
            g.pageY = f.pageY),
            g.target || (g.target = f.target),
            g.which === b && (g.which = g.button),
            g.preventDefault || (g.preventDefault = f.preventDefault),
            g.stopPropagation || (g.stopPropagation = f.stopPropagation),
            d.call(this, g)
        })
    }
    ,
    Hammer.Instance.prototype.on = function(c, d) {
        return a(this.element).on(c, d)
    }
    ,
    Hammer.Instance.prototype.off = function(c, d) {
        return a(this.element).off(c, d)
    }
    ,
    Hammer.Instance.prototype.trigger = function(d, f) {
        var c = a(this.element);
        return c.has(f.target).length && (c = a(f.target)),
        c.trigger({
            type: d,
            gesture: f
        })
    }
    ,
    a.fn.hammer = function(c) {
        return this.each(function() {
            var e = a(this)
              , d = e.data("hammer");
            d ? d && c && Hammer.utils.extend(d.options, c) : e.data("hammer", new Hammer(this,c || {}))
        })
    }
    )
}(window.jQuery || window.Zepto);
