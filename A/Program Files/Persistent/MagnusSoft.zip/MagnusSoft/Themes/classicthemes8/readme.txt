Installation notes:
1. Run "install.cmd" file.
2. Right click on Desktop and open Personalization from the context menu.
3. Select a theme.
4. Enjoy
5. Visit our website: http://windows8themes.ms